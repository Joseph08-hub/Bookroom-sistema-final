import os
import re
import calendar
import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector
from datetime import datetime, date, timedelta
from PIL import Image, ImageTk, ImageDraw, ImageFont
COLOR_NAVY = "#1A3E5C"
COLOR_BLUE = "#2B6CB0"
COLOR_TEAL = "#00C9B7"
COLOR_BG = "#F7FAFC"

COLOR_BLANCO = "#FFFFFF"
COLOR_NEGRO_TEXTO = "#0C0C0C"

FUENTE_TITULO = ("Georgia", 20, "bold")
FUENTE_SUBTITULO = ("Georgia", 10)
FUENTE_LABEL = ("Georgia", 9, "bold")
FUENTE_CAMPO = ("Georgia", 11)
FUENTE_BOTON = ("Georgia", 10, "bold")
FUENTE_NAV = ("Georgia", 11)
FUENTE_TABLA_HEADER = ("Georgia", 10, "bold")
FUENTE_TABLA = ("Georgia", 10)

RUTA_ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
RUTA_HABITACIONES = os.path.join(RUTA_ASSETS, "habitaciones")

COLORES_RESPALDO_TIPOS = [COLOR_NAVY, COLOR_BLUE, COLOR_TEAL, "#3d6d8a"]

MESES_ES = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio",
            "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]
DIAS_ES = ["Lu", "Ma", "Mi", "Ju", "Vi", "Sá", "Do"]


def dibujar_pill(canvas, x1, y1, x2, y2, relleno, borde, grosor=2):
    r = (y2 - y1) / 2
    canvas.create_oval(x1, y1, x1 + 2 * r, y2, fill=relleno, outline=relleno)
    canvas.create_oval(x2 - 2 * r, y1, x2, y2, fill=relleno, outline=relleno)
    canvas.create_rectangle(x1 + r, y1, x2 - r, y2, fill=relleno, outline=relleno)
    canvas.create_arc(x1, y1, x1 + 2 * r, y2, start=90, extent=180,
                       style="arc", outline=borde, width=grosor)
    canvas.create_arc(x2 - 2 * r, y1, x2, y2, start=-90, extent=180,
                       style="arc", outline=borde, width=grosor)
    canvas.create_line(x1 + r, y1, x2 - r, y1, fill=borde, width=grosor)
    canvas.create_line(x1 + r, y2, x2 - r, y2, fill=borde, width=grosor)


def crear_campo_pill(parent, texto_label, ancho=340, alto=42, es_password=False, show_default=""):
    tk.Label(
        parent, text=texto_label, font=FUENTE_LABEL,
        bg=COLOR_BG, fg=COLOR_NAVY
    ).pack(anchor="w", pady=(10, 3))

    canvas = tk.Canvas(parent, width=ancho, height=alto, bg=COLOR_BG, highlightthickness=0)
    canvas.pack()

    dibujar_pill(canvas, 1, 1, ancho - 1, alto - 1, COLOR_BLANCO, COLOR_TEAL, grosor=2)

    margen_izq = 16
    margen_der = 40 if es_password else 16
    entry_ancho = ancho - margen_izq - margen_der
    entry_alto = alto - 14

    entrada = tk.Entry(
        canvas, font=FUENTE_CAMPO, bg=COLOR_BLANCO, fg=COLOR_NAVY,
        insertbackground=COLOR_NAVY, relief="flat", bd=0, highlightthickness=0,
        show=("*" if es_password else show_default)
    )
    canvas.create_window(margen_izq, alto / 2, window=entrada, anchor="w",
                          width=entry_ancho, height=entry_alto)

    if es_password:
        icono_id = canvas.create_text(ancho - 22, alto / 2, text="\U0001F441",
                                       font=("Segoe UI", 12), fill=COLOR_NAVY)
        estado = {"visible": False}

        def alternar_visibilidad(event=None):
            estado["visible"] = not estado["visible"]
            if estado["visible"]:
                entrada.config(show="")
                canvas.itemconfig(icono_id, text="\U0001F648")
            else:
                entrada.config(show="*")
                canvas.itemconfig(icono_id, text="\U0001F441")

        canvas.tag_bind(icono_id, "<Button-1>", alternar_visibilidad)
        canvas.tag_bind(icono_id, "<Enter>", lambda e: canvas.config(cursor="hand2"))
        canvas.tag_bind(icono_id, "<Leave>", lambda e: canvas.config(cursor=""))

    return entrada


def crear_boton_pill(parent, texto, comando, ancho=150, alto=42, primario=True, side="right", padx=(10, 0)):
    canvas = tk.Canvas(parent, width=ancho, height=alto, bg=parent["bg"], highlightthickness=0)
    canvas.pack(side=side, padx=padx)

    if primario:
        relleno = COLOR_TEAL
        borde = COLOR_TEAL
        color_texto = COLOR_NAVY
    else:
        relleno = parent["bg"]
        borde = COLOR_NAVY
        color_texto = COLOR_NAVY

    dibujar_pill(canvas, 1, 1, ancho - 1, alto - 1, relleno, borde, grosor=2)
    canvas.create_text(ancho / 2, alto / 2, text=texto, font=FUENTE_BOTON, fill=color_texto)

    def click(event=None):
        comando()

    canvas.bind("<Button-1>", click)
    canvas.bind("<Enter>", lambda e: canvas.config(cursor="hand2"))
    canvas.bind("<Leave>", lambda e: canvas.config(cursor=""))

    return canvas


def _cargar_logo(nombre_archivo, ancho):
    ruta = os.path.join(RUTA_ASSETS, nombre_archivo)
    if not os.path.isfile(ruta):
        return None
    imagen = Image.open(ruta).convert("RGBA")
    ratio = ancho / imagen.width
    alto = int(imagen.height * ratio)
    imagen = imagen.resize((ancho, alto), Image.LANCZOS)
    tk_imagen = ImageTk.PhotoImage(imagen)
    return tk_imagen


def aplicar_icono(ventana):
    """Reemplaza la pluma de Tkinter por el logo de BookRoom.

    Si existe assets/bookroom_icon.ico se usa ese; si no, se arma el ícono
    a partir de assets/bookroom_icon.png (el mismo que se ve en el sidebar).
    Con default=True, también se aplica a las ventanas hijas (recibos, registro, etc.).
    """
    try:
        ruta_ico = os.path.join(RUTA_ASSETS, "bookroom_icon.ico")
        if os.path.isfile(ruta_ico):
            ventana.iconbitmap(default=ruta_ico)
            return
    except Exception:
        pass

    try:
        ruta_png = os.path.join(RUTA_ASSETS, "bookroom_icon.png")
        if not os.path.isfile(ruta_png):
            return
        logo = Image.open(ruta_png).convert("RGBA")
        tam = 64
        base = Image.new("RGBA", (tam, tam), (0, 0, 0, 0))
        dibujo = ImageDraw.Draw(base)
        dibujo.ellipse([1, 1, tam - 2, tam - 2], fill=(255, 255, 255, 255),
                        outline=(0, 201, 183, 255), width=3)
        ancho_logo = 36
        alto_logo = int(logo.height * ancho_logo / logo.width)
        logo = logo.resize((ancho_logo, alto_logo), Image.LANCZOS)
        base.paste(logo, ((tam - ancho_logo) // 2, (tam - alto_logo) // 2), logo)
        foto = ImageTk.PhotoImage(base)
        ventana.iconphoto(True, foto)
        ventana._icono_bookroom = foto
    except Exception:
        pass


def crear_sidebar(parent, alto, texto_slogan="Gestión hotelera al día", ancho=250, con_navegacion=False):
    sidebar = tk.Frame(parent, bg=COLOR_NAVY, width=ancho, height=alto)
    sidebar.pack(side="left", fill="y")
    sidebar.pack_propagate(False)

    if con_navegacion:
        contenedor = tk.Frame(sidebar, bg=COLOR_NAVY)
        contenedor.pack(side="top", pady=(45, 15))
    else:
        area_logo = tk.Frame(sidebar, bg=COLOR_NAVY)
        area_logo.pack(fill="both", expand=True)
        contenedor = tk.Frame(area_logo, bg=COLOR_NAVY)
        contenedor.place(relx=0.5, rely=0.46, anchor="center")

    diametro = 120
    placa = tk.Canvas(contenedor, width=diametro, height=diametro, bg=COLOR_NAVY, highlightthickness=0)
    placa.pack(pady=(0, 16))
    placa.create_oval(4, 4, diametro - 4, diametro - 4, outline=COLOR_TEAL, width=2, fill=COLOR_BLANCO)

    logo_img = _cargar_logo("bookroom_icon.png", ancho=64)
    if logo_img is not None:
        placa.create_image(diametro / 2, diametro / 2, image=logo_img)
        placa.image = logo_img
    else:
        placa.create_text(diametro / 2, diametro / 2, text="BR",
                           font=("Georgia", 24, "bold"), fill=COLOR_NAVY)

    tk.Label(
        contenedor, text="BOOKROOM",
        font=("Georgia", 17, "bold"),
        bg=COLOR_NAVY, fg=COLOR_BLANCO
    ).pack()

    tk.Label(
        contenedor, text=texto_slogan,
        font=("Georgia", 9, "italic"),
        bg=COLOR_NAVY, fg=COLOR_TEAL
    ).pack(pady=(4, 0))

    return sidebar


def logo_encabezado(parent, ancho=150):
    logo_img = _cargar_logo("bookroom_logo.png", ancho=ancho)
    if logo_img is None:
        return None
    lbl = tk.Label(parent, image=logo_img, bg=parent["bg"])
    lbl.image = logo_img
    return lbl


def _nombre_archivo_tipo(nombre_tipo):
    texto = nombre_tipo.strip().lower()
    reemplazos = {"á": "a", "é": "e", "í": "i", "ó": "o", "ú": "u", "ñ": "n", " ": "_"}
    for viejo, nuevo in reemplazos.items():
        texto = texto.replace(viejo, nuevo)
    return texto


def _color_respaldo_tipo(nombre_tipo):
    indice = abs(hash(nombre_tipo)) % len(COLORES_RESPALDO_TIPOS)
    return COLORES_RESPALDO_TIPOS[indice]


def _generar_placeholder_habitacion(nombre_tipo, ancho, alto, variante=0):
    color_fondo = _color_respaldo_tipo(nombre_tipo + str(variante))
    imagen = Image.new("RGB", (ancho, alto), color_fondo)
    dibujo = ImageDraw.Draw(imagen)

    m = int(alto * 0.18)
    offset = variante * int(ancho * 0.04)
    cama_x1, cama_y1 = int(ancho * 0.15) + offset, int(alto * 0.45)
    cama_x2, cama_y2 = int(ancho * 0.85), int(alto * 0.78)
    dibujo.rounded_rectangle([cama_x1, cama_y1, cama_x2, cama_y2], radius=8, fill=COLOR_BLANCO)
    dibujo.rounded_rectangle(
        [cama_x1, cama_y1 - m, cama_x1 + int((cama_x2 - cama_x1) * 0.32), cama_y1 + 10],
        radius=6, fill=COLOR_BLANCO
    )

    try:
        fuente = ImageFont.truetype("arial.ttf", max(11, int(alto * 0.13)))
    except Exception:
        fuente = ImageFont.load_default()

    texto = nombre_tipo.upper() + (f" · {variante + 1}" if variante else "")
    bbox = dibujo.textbbox((0, 0), texto, font=fuente)
    tw = bbox[2] - bbox[0]
    dibujo.text(((ancho - tw) / 2, int(alto * 0.06)), texto, font=fuente, fill=COLOR_BLANCO)
    return imagen


def imagen_habitacion(habitacion, ancho=200, alto=130):
    numero = habitacion["numero_habitacion"]
    for extension in (".jpg", ".jpeg", ".png"):
        ruta = os.path.join(RUTA_HABITACIONES, f"imagen1({numero}){extension}")
        if os.path.isfile(ruta):
            imagen = Image.open(ruta).convert("RGB")
            imagen = imagen.resize((ancho, alto), Image.LANCZOS)
            return ImageTk.PhotoImage(imagen)

    imagen = _generar_placeholder_habitacion(habitacion["nombre_tipo"], ancho, alto, 0)
    return ImageTk.PhotoImage(imagen)


def listar_fotos_habitacion(habitacion, ancho=520, alto=340):
    numero = habitacion["numero_habitacion"]
    rutas_encontradas = []
    for indice in range(1, 9):
        for extension in (".jpg", ".jpeg", ".png"):
            ruta = os.path.join(RUTA_HABITACIONES, f"imagen{indice}({numero}){extension}")
            if os.path.isfile(ruta):
                rutas_encontradas.append(ruta)
                break

    if rutas_encontradas:
        fotos = []
        for ruta in rutas_encontradas:
            imagen = Image.open(ruta).convert("RGB")
            imagen = imagen.resize((ancho, alto), Image.LANCZOS)
            fotos.append(ImageTk.PhotoImage(imagen))
        return fotos

    return [ImageTk.PhotoImage(_generar_placeholder_habitacion(habitacion["nombre_tipo"], ancho, alto, v))
            for v in range(3)]


def crear_area_scroll(parent, alto=260):
    contenedor = tk.Frame(parent, bg=COLOR_BG)
    contenedor.pack(fill="both", expand=True, padx=24, pady=(4, 10))

    canvas = tk.Canvas(contenedor, bg=COLOR_BG, highlightthickness=0)
    scroll = ttk.Scrollbar(contenedor, orient="vertical", command=canvas.yview)
    interior = tk.Frame(canvas, bg=COLOR_BG)

    ventana_interior = canvas.create_window((0, 0), window=interior, anchor="nw")
    interior.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.bind("<Configure>", lambda e: canvas.itemconfig(ventana_interior, width=e.width))
    canvas.configure(yscrollcommand=scroll.set)

    canvas.pack(side="left", fill="both", expand=True)
    scroll.pack(side="right", fill="y")

    def _rueda(event):
        canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", _rueda))
    canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))

    return interior


_COLORES_ESTADO = {
    "Disponible": COLOR_TEAL,
    "Ocupada": COLOR_BLUE,
    "Mantenimiento": COLOR_NAVY,
}


def mostrar_carrusel_habitacion(habitacion):
    fotos = listar_fotos_habitacion(habitacion, ancho=520, alto=340)
    indice = {"valor": 0}

    ventana = tk.Toplevel()
    ventana.title(f"BookRoom - Habitación {habitacion['numero_habitacion']}")
    ventana.geometry("600x700")
    ventana.minsize(600, 700)
    ventana.resizable(True, True)
    ventana.config(bg=COLOR_BG)

    tk.Label(ventana, text=f"Habitación {habitacion['numero_habitacion']} · {habitacion['nombre_tipo']}",
              font=("Georgia", 15, "bold"), bg=COLOR_BG, fg=COLOR_NAVY).pack(pady=(18, 2))
    tk.Label(ventana, text=f"${float(habitacion['precio_por_noche']):.2f} / noche  ·  {habitacion['estado']}",
              font=FUENTE_SUBTITULO, bg=COLOR_BG, fg=COLOR_BLUE).pack(pady=(0, 12))

    marco_img = tk.Frame(ventana, bg=COLOR_BLANCO, highlightbackground=COLOR_TEAL, highlightthickness=1)
    marco_img.pack(padx=24)
    lbl_foto = tk.Label(marco_img, image=fotos[0], bg=COLOR_BLANCO)
    lbl_foto.image = fotos[0]
    lbl_foto.pack()

    contador = tk.Label(ventana, text=f"1 / {len(fotos)}", font=FUENTE_SUBTITULO, bg=COLOR_BG, fg=COLOR_BLUE)
    contador.pack(pady=(10, 0))

    def mostrar(i):
        indice["valor"] = i % len(fotos)
        lbl_foto.config(image=fotos[indice["valor"]])
        lbl_foto.image = fotos[indice["valor"]]
        contador.config(text=f"{indice['valor'] + 1} / {len(fotos)}")

    frame_nav = tk.Frame(ventana, bg=COLOR_BG)
    frame_nav.pack(pady=22)
    boton_accion(frame_nav, "Anterior", lambda: mostrar(indice["valor"] - 1), primario=False, ancho=130)
    boton_accion(frame_nav, "Siguiente", lambda: mostrar(indice["valor"] + 1), primario=True, ancho=130)
    boton_accion(frame_nav, "Cerrar", ventana.destroy, primario=False, ancho=110)


def tarjeta_habitacion(parent, habitacion):
    tarjeta = tk.Frame(parent, bg=COLOR_BLANCO, highlightbackground=COLOR_NAVY, highlightthickness=1)

    img = imagen_habitacion(habitacion, ancho=200, alto=110)
    lbl_img = tk.Label(tarjeta, image=img, bg=COLOR_BLANCO, cursor="hand2")
    lbl_img.image = img
    lbl_img.pack()
    lbl_img.bind("<Button-1>", lambda e: mostrar_carrusel_habitacion(habitacion))

    info = tk.Frame(tarjeta, bg=COLOR_BLANCO)
    info.pack(fill="x", padx=10, pady=(8, 10))

    fila_top = tk.Frame(info, bg=COLOR_BLANCO)
    fila_top.pack(fill="x")
    tk.Label(fila_top, text=f"Hab. {habitacion['numero_habitacion']}", font=("Georgia", 11, "bold"),
              bg=COLOR_BLANCO, fg=COLOR_NAVY).pack(side="left")

    color_estado = _COLORES_ESTADO.get(habitacion["estado"], COLOR_NAVY)
    tk.Label(fila_top, text=habitacion["estado"], font=("Georgia", 8, "bold"),
              bg=COLOR_BLANCO, fg=color_estado).pack(side="right")

    tk.Label(info, text=habitacion["nombre_tipo"], font=FUENTE_SUBTITULO,
              bg=COLOR_BLANCO, fg=COLOR_BLUE).pack(anchor="w", pady=(2, 0))

    tk.Label(info, text=f"${float(habitacion['precio_por_noche']):.2f} / noche",
              font=("Georgia", 10, "bold"), bg=COLOR_BLANCO, fg=COLOR_TEAL).pack(anchor="w", pady=(4, 0))

    return tarjeta


def construir_grid_habitaciones(parent, habitaciones, columnas=4):
    tk.Label(parent, text="Habitaciones", font=("Georgia", 13, "bold"),
              bg=COLOR_BG, fg=COLOR_NAVY).pack(anchor="w", padx=24, pady=(18, 4))

    interior = crear_area_scroll(parent, alto=280)

    for i, hab in enumerate(habitaciones):
        fila, col = divmod(i, columnas)
        tarjeta = tarjeta_habitacion(interior, hab)
        tarjeta.grid(row=fila, column=col, padx=10, pady=10, sticky="nsew")

    for c in range(columnas):
        interior.grid_columnconfigure(c, weight=1)


ROL_PERMITIDO_EN_REGISTRO_PUBLICO = "empleado"


def hash_password(password_texto_plano: str) -> str:
    return password_texto_plano


def verificar_password(password_texto_plano: str, hash_guardado: str) -> bool:
    return password_texto_plano == hash_guardado


def validar_datos_huesped(doc, nom, ape, tel, correo):
    """Devuelve un mensaje de error si algún dato del huésped no es válido, o None si todo está bien."""
    if not re.fullmatch(r"[A-Za-z0-9\-]{4,20}", doc):
        return "El documento solo puede llevar letras, números y guiones (entre 4 y 20 caracteres)."
    patron_nombre = r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ' .\-]{2,50}"
    if not re.fullmatch(patron_nombre, nom):
        return "El nombre solo puede contener letras (sin números ni símbolos)."
    if not re.fullmatch(patron_nombre, ape):
        return "El apellido solo puede contener letras (sin números ni símbolos)."
    if tel:
        cantidad_digitos = len(re.sub(r"\D", "", tel))
        if not re.fullmatch(r"[0-9+\-\s()]+", tel) or not (7 <= cantidad_digitos <= 15):
            return "El teléfono solo puede contener números (entre 7 y 15 dígitos), espacios, + o guiones."
    if correo and not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", correo):
        return "El correo no tiene un formato válido (ejemplo: nombre@correo.com)."
    return None


CONFIG_DB = {
    "host": "localhost",
    "user": "root",
    "password": "Inframen2025",
    "database": "bookroom",
}


def conectar():
    return mysql.connector.connect(**CONFIG_DB)


def asegurar_columnas_horas():
    """Agrega hora_entrada y hora_salida a la tabla reservas si todavía no existen (solo la primera vez)."""
    conexion = conectar()
    cursor = conexion.cursor()
    for columna in ("hora_entrada", "hora_salida"):
        cursor.execute(
            "SELECT COUNT(*) FROM information_schema.COLUMNS "
            "WHERE TABLE_SCHEMA=%s AND TABLE_NAME='reservas' AND COLUMN_NAME=%s",
            (CONFIG_DB["database"], columna)
        )
        if cursor.fetchone()[0] == 0:
            cursor.execute(f"ALTER TABLE reservas ADD COLUMN {columna} TIME NULL")
    conexion.commit()
    conexion.close()


class PanelBase:

    def __init__(self, sesion, titulo_ventana, secciones, slogan):
        self.sesion = sesion
        self.secciones = secciones
        self.botones_nav = {}

        self.root = tk.Tk()
        self.root.title(titulo_ventana)
        self.root.geometry("1180x680")
        self.root.minsize(1000, 600)
        self.root.config(bg=COLOR_BG)
        aplicar_icono(self.root)

        self._construir_sidebar(slogan)
        self._construir_area_principal()

        primera_clave = secciones[0][0]
        self.mostrar_seccion(primera_clave)

        self.root.mainloop()

    def _construir_sidebar(self, slogan):
        self.sidebar = crear_sidebar(self.root, 680, texto_slogan=slogan, ancho=230, con_navegacion=True)

        salir_frame = tk.Frame(self.sidebar, bg=COLOR_NAVY)
        salir_frame.pack(side="bottom", pady=22)
        salir_lbl = tk.Label(salir_frame, text="Cerrar sesión", font=FUENTE_NAV,
                              bg=COLOR_NAVY, fg=COLOR_TEAL, cursor="hand2")
        salir_lbl.pack()
        salir_lbl.bind("<Button-1>", lambda e: self._cerrar_sesion())

        nav_container = tk.Frame(self.sidebar, bg=COLOR_NAVY)
        nav_container.pack(side="top", fill="x", pady=(20, 0))

        for clave, etiqueta, _fn in self.secciones:
            self._crear_boton_nav(nav_container, clave, etiqueta)

    def _crear_boton_nav(self, parent, clave, etiqueta):
        fila = tk.Frame(parent, bg=COLOR_NAVY)
        fila.pack(fill="x", pady=2, padx=14)

        lbl = tk.Label(fila, text=etiqueta, font=FUENTE_NAV, bg=COLOR_NAVY,
                        fg=COLOR_BLANCO, anchor="w", padx=14, pady=10, cursor="hand2")
        lbl.pack(fill="x")

        def on_click(e=None, c=clave):
            self.mostrar_seccion(c)

        def on_enter(e):
            if self.seccion_activa != clave:
                lbl.config(bg=COLOR_BLUE)
                fila.config(bg=COLOR_BLUE)

        def on_leave(e):
            if self.seccion_activa != clave:
                lbl.config(bg=COLOR_NAVY)
                fila.config(bg=COLOR_NAVY)

        lbl.bind("<Button-1>", on_click)
        lbl.bind("<Enter>", on_enter)
        lbl.bind("<Leave>", on_leave)

        self.botones_nav[clave] = (fila, lbl)

    def _construir_area_principal(self):
        contenedor = tk.Frame(self.root, bg=COLOR_BG)
        contenedor.pack(side="left", fill="both", expand=True)

        topbar = tk.Frame(contenedor, bg=COLOR_BLANCO, height=56)
        topbar.pack(fill="x")
        topbar.pack_propagate(False)

        rol_visible = "Administrador" if self.sesion["rol"] == "administrador" else "Empleado"
        tk.Label(
            topbar, text=f"{self.sesion['nombre_completo']}   •   {rol_visible}",
            font=FUENTE_SUBTITULO, bg=COLOR_BLANCO, fg=COLOR_NAVY
        ).pack(side="right", padx=24)

        self.titulo_seccion = tk.Label(topbar, text="", font=FUENTE_TITULO,
                                        bg=COLOR_BLANCO, fg=COLOR_NAVY)
        self.titulo_seccion.pack(side="left", padx=24)

        borde = tk.Frame(contenedor, bg=COLOR_TEAL, height=2)
        borde.pack(fill="x")

        self.frame_contenido = tk.Frame(contenedor, bg=COLOR_BG)
        self.frame_contenido.pack(fill="both", expand=True)

        self.seccion_activa = None

    def mostrar_seccion(self, clave):
        for c, (fila, lbl) in self.botones_nav.items():
            color = COLOR_TEAL if c == clave else COLOR_NAVY
            texto_color = COLOR_NAVY if c == clave else COLOR_BLANCO
            fila.config(bg=color)
            lbl.config(bg=color, fg=texto_color)

        self.seccion_activa = clave

        for widget in self.frame_contenido.winfo_children():
            widget.destroy()

        etiqueta, funcion = next((e, f) for c, e, f in self.secciones if c == clave)
        self.titulo_seccion.config(text=etiqueta)
        funcion(self.frame_contenido, self.sesion)

    def _cerrar_sesion(self):
        if messagebox.askyesno("Cerrar sesión", "¿Deseas cerrar tu sesión?", parent=self.root):
            self.root.destroy()
            construir_login()


def estilo_treeview():
    estilo = ttk.Style()
    estilo.theme_use("clam")
    estilo.configure("BookRoom.Treeview",
                      background=COLOR_BLANCO, fieldbackground=COLOR_BLANCO,
                      foreground=COLOR_NAVY, rowheight=28, font=FUENTE_TABLA, borderwidth=0)
    estilo.configure("BookRoom.Treeview.Heading",
                      background=COLOR_NAVY, foreground=COLOR_BLANCO,
                      font=FUENTE_TABLA_HEADER, relief="flat")
    estilo.map("BookRoom.Treeview.Heading", background=[("active", COLOR_BLUE)])
    estilo.map("BookRoom.Treeview", background=[("selected", COLOR_TEAL)],
               foreground=[("selected", COLOR_NAVY)])
    return estilo


def crear_tabla(parent, columnas):
    estilo_treeview()
    marco = tk.Frame(parent, bg=COLOR_BG)
    marco.pack(fill="both", expand=True, padx=24, pady=(16, 8))

    claves = [c[0] for c in columnas]
    tabla = ttk.Treeview(marco, columns=claves, show="headings", style="BookRoom.Treeview")
    for clave, titulo, ancho in columnas:
        tabla.heading(clave, text=titulo)
        tabla.column(clave, width=ancho, anchor="w")

    scroll = ttk.Scrollbar(marco, orient="vertical", command=tabla.yview)
    tabla.configure(yscrollcommand=scroll.set)
    tabla.pack(side="left", fill="both", expand=True)
    scroll.pack(side="right", fill="y")

    return tabla


def campo_simple(parent, texto_label, ancho=26, valores_combo=None):
    tk.Label(parent, text=texto_label, font=FUENTE_LABEL, bg=COLOR_BG, fg=COLOR_NAVY) \
        .pack(anchor="w", pady=(8, 2))

    if valores_combo is not None:
        var = tk.StringVar()
        combo = ttk.Combobox(parent, textvariable=var, values=valores_combo,
                              font=FUENTE_CAMPO, width=ancho - 2, state="readonly")
        combo.pack(anchor="w", ipady=3)
        return combo
    else:
        entrada = tk.Entry(parent, font=FUENTE_CAMPO, width=ancho, bg=COLOR_BLANCO,
                            fg=COLOR_NAVY, relief="solid", bd=1,
                            highlightthickness=1, highlightbackground=COLOR_TEAL,
                            highlightcolor=COLOR_TEAL, insertbackground=COLOR_NAVY)
        entrada.pack(anchor="w", ipady=4)
        return entrada


class EntradaFecha(tk.Entry):
    """Entry de solo lectura (la fecha se elige con el calendario) que sigue
    aceptando .insert() y .delete() desde el código, igual que un Entry normal."""

    def _con_edicion(self, funcion, *args):
        estado = str(self.cget("state"))
        self.config(state="normal")
        try:
            funcion(*args)
        finally:
            self.config(state=estado)

    def insert(self, index, string):
        self._con_edicion(super().insert, index, string)

    def delete(self, first, last=None):
        self._con_edicion(super().delete, first, last)


def abrir_calendario(entrada, al_cambiar=None):
    try:
        actual = datetime.strptime(entrada.get().strip(), "%Y-%m-%d").date()
    except ValueError:
        actual = None
    hoy = datetime.now().date()
    base = actual or hoy
    vista = {"anio": base.year, "mes": base.month}

    padre = entrada.winfo_toplevel()
    ventana = tk.Toplevel(padre)
    ventana.title("Seleccionar fecha")
    ventana.resizable(False, False)
    ventana.config(bg=COLOR_BLANCO, highlightbackground=COLOR_TEAL, highlightthickness=2)
    ventana.transient(padre)

    x = entrada.winfo_rootx()
    y = entrada.winfo_rooty() + entrada.winfo_height() + 4
    ventana.geometry(f"+{x}+{y}")

    encabezado = tk.Frame(ventana, bg=COLOR_NAVY)
    encabezado.pack(fill="x")

    btn_ant = tk.Label(encabezado, text="◀", font=("Georgia", 12, "bold"), bg=COLOR_NAVY,
                        fg=COLOR_TEAL, cursor="hand2", padx=12, pady=6)
    btn_ant.pack(side="left")
    btn_sig = tk.Label(encabezado, text="▶", font=("Georgia", 12, "bold"), bg=COLOR_NAVY,
                        fg=COLOR_TEAL, cursor="hand2", padx=12, pady=6)
    btn_sig.pack(side="right")
    titulo = tk.Label(encabezado, text="", font=("Georgia", 11, "bold"), bg=COLOR_NAVY, fg=COLOR_BLANCO)
    titulo.pack(side="left", expand=True)

    cuadricula = tk.Frame(ventana, bg=COLOR_BLANCO)
    cuadricula.pack(padx=8, pady=(0, 4))

    def elegir(fecha_elegida):
        entrada.delete(0, tk.END)
        entrada.insert(0, fecha_elegida.strftime("%Y-%m-%d"))
        ventana.destroy()
        if al_cambiar:
            al_cambiar()

    def dibujar():
        for w in cuadricula.winfo_children():
            w.destroy()
        titulo.config(text=f"{MESES_ES[vista['mes'] - 1]} {vista['anio']}")

        for c, dia_nombre in enumerate(DIAS_ES):
            tk.Label(cuadricula, text=dia_nombre, font=FUENTE_LABEL, bg=COLOR_BLANCO,
                      fg=COLOR_BLUE, width=4).grid(row=0, column=c, pady=(8, 2))

        for fila, semana in enumerate(calendar.monthcalendar(vista["anio"], vista["mes"]), start=1):
            for c, dia in enumerate(semana):
                if dia == 0:
                    tk.Label(cuadricula, text="", width=4, bg=COLOR_BLANCO).grid(row=fila, column=c)
                    continue
                fecha_dia = date(vista["anio"], vista["mes"], dia)
                if actual and fecha_dia == actual:
                    fondo, fuente = COLOR_TEAL, ("Georgia", 10, "bold")
                elif fecha_dia == hoy:
                    fondo, fuente = "#CFF5F1", ("Georgia", 10, "bold")
                else:
                    fondo, fuente = COLOR_BLANCO, FUENTE_TABLA
                lbl = tk.Label(cuadricula, text=str(dia), font=fuente, width=4, pady=4,
                                bg=fondo, fg=COLOR_NAVY, cursor="hand2")
                lbl.grid(row=fila, column=c, padx=1, pady=1)
                lbl.bind("<Button-1>", lambda e, f=fecha_dia: elegir(f))
                lbl.bind("<Enter>", lambda e, w=lbl: w.config(bg=COLOR_BLUE, fg=COLOR_BLANCO))
                lbl.bind("<Leave>", lambda e, w=lbl, b=fondo: w.config(bg=b, fg=COLOR_NAVY))

    def mover(delta):
        mes = vista["mes"] + delta
        anio = vista["anio"]
        if mes < 1:
            mes, anio = 12, anio - 1
        elif mes > 12:
            mes, anio = 1, anio + 1
        vista["mes"], vista["anio"] = mes, anio
        dibujar()

    btn_ant.bind("<Button-1>", lambda e: mover(-1))
    btn_sig.bind("<Button-1>", lambda e: mover(1))

    pie = tk.Frame(ventana, bg=COLOR_BLANCO)
    pie.pack(fill="x", pady=(0, 8))
    lbl_hoy = tk.Label(pie, text="Hoy", font=("Georgia", 10, "bold underline"), bg=COLOR_BLANCO,
                        fg=COLOR_NAVY, cursor="hand2")
    lbl_hoy.pack(side="left", padx=14)
    lbl_hoy.bind("<Button-1>", lambda e: elegir(hoy))
    lbl_cerrar = tk.Label(pie, text="Cerrar", font=("Georgia", 10), bg=COLOR_BLANCO,
                           fg=COLOR_BLUE, cursor="hand2")
    lbl_cerrar.pack(side="right", padx=14)
    lbl_cerrar.bind("<Button-1>", lambda e: ventana.destroy())

    ventana.bind("<Escape>", lambda e: ventana.destroy())
    dibujar()

    try:
        ventana.wait_visibility()
        ventana.grab_set()
        ventana.focus_set()
    except tk.TclError:
        pass


def campo_fecha(parent, texto_label, ancho=22, al_cambiar=None):
    """Campo de fecha con calendario desplegable. Devuelve un Entry con la fecha en formato AAAA-MM-DD."""
    tk.Label(parent, text=texto_label, font=FUENTE_LABEL, bg=COLOR_BG, fg=COLOR_NAVY) \
        .pack(anchor="w", pady=(8, 2))

    fila = tk.Frame(parent, bg=COLOR_BG)
    fila.pack(anchor="w")

    entrada = EntradaFecha(
        fila, font=FUENTE_CAMPO, width=max(ancho - 4, 10), bg=COLOR_BLANCO, fg=COLOR_NAVY,
        readonlybackground=COLOR_BLANCO, relief="solid", bd=1,
        highlightthickness=1, highlightbackground=COLOR_TEAL, highlightcolor=COLOR_TEAL,
        insertbackground=COLOR_NAVY, state="readonly", cursor="hand2"
    )
    entrada.pack(side="left", ipady=4)

    boton = tk.Label(fila, text="\U0001F4C5", font=("Segoe UI Emoji", 12), bg=COLOR_TEAL,
                      fg=COLOR_NAVY, padx=8, cursor="hand2")
    boton.pack(side="left", padx=(4, 0), fill="y")

    def abrir(event=None):
        abrir_calendario(entrada, al_cambiar)

    entrada.bind("<Button-1>", abrir)
    boton.bind("<Button-1>", abrir)

    return entrada


def _formatear_hora(valor):
    """MySQL devuelve los campos TIME como timedelta; aquí se convierten a 'HH:MM'."""
    if valor is None:
        return ""
    if isinstance(valor, timedelta):
        total = int(valor.total_seconds())
        return f"{total // 3600:02d}:{(total % 3600) // 60:02d}"
    return str(valor)[:5]


def _fecha_con_hora(fecha, hora):
    return f"{fecha} {_formatear_hora(hora)}".strip()


class CampoHora:
    """Selector de hora (HH:MM, formato 24 horas). Empieza con la hora actual."""

    def __init__(self, parent, texto_label, al_cambiar=None):
        tk.Label(parent, text=texto_label, font=FUENTE_LABEL, bg=COLOR_BG, fg=COLOR_NAVY) \
            .pack(anchor="w", pady=(8, 2))
        fila = tk.Frame(parent, bg=COLOR_BG)
        fila.pack(anchor="w")

        ahora = datetime.now()
        self.var_h = tk.StringVar(value=f"{ahora.hour:02d}")
        self.var_m = tk.StringVar(value=f"{ahora.minute:02d}")
        self._al_cambiar = al_cambiar

        def crear_spin(variable, maximo):
            spin = tk.Spinbox(
                fila, from_=0, to=maximo, width=3, format="%02.0f", wrap=True,
                textvariable=variable, font=FUENTE_CAMPO, justify="center",
                bg=COLOR_BLANCO, fg=COLOR_NAVY, relief="solid", bd=1,
                highlightthickness=1, highlightbackground=COLOR_TEAL, highlightcolor=COLOR_TEAL,
                buttonbackground=COLOR_BG, command=self._notificar
            )
            spin.bind("<KeyRelease>", lambda e: self._notificar())
            return spin

        crear_spin(self.var_h, 23).pack(side="left", ipady=3)
        tk.Label(fila, text=":", font=("Georgia", 12, "bold"), bg=COLOR_BG, fg=COLOR_NAVY) \
            .pack(side="left", padx=3)
        crear_spin(self.var_m, 59).pack(side="left", ipady=3)

        lbl_ahora = tk.Label(fila, text="Ahora", font=("Georgia", 10, "bold underline"),
                              bg=COLOR_BG, fg=COLOR_NAVY, cursor="hand2")
        lbl_ahora.pack(side="left", padx=(10, 0))
        lbl_ahora.bind("<Button-1>", lambda e: self.poner_ahora())

    def _notificar(self):
        if self._al_cambiar:
            self._al_cambiar()

    def poner_ahora(self):
        ahora = datetime.now()
        self.var_h.set(f"{ahora.hour:02d}")
        self.var_m.set(f"{ahora.minute:02d}")
        self._notificar()

    def valor(self):
        """Devuelve 'HH:MM' o None si la hora no es válida."""
        try:
            h = int(self.var_h.get())
            m = int(self.var_m.get())
        except ValueError:
            return None
        if 0 <= h <= 23 and 0 <= m <= 59:
            return f"{h:02d}:{m:02d}"
        return None


def texto_estadia(entrada, hora, salida):
    """Texto informativo: noches, horas totales y hora de salida calculada automáticamente."""
    try:
        f_in = datetime.strptime(entrada, "%Y-%m-%d")
        f_out = datetime.strptime(salida, "%Y-%m-%d")
    except ValueError:
        return "Elige la fecha de entrada, la hora y la fecha de salida."
    if hora is None:
        return "La hora de entrada no es válida (horas 00-23, minutos 00-59)."
    noches = (f_out - f_in).days
    if noches <= 0:
        return "La fecha de salida debe ser posterior a la de entrada."
    return (f"Estadía: {noches} noche(s) = {noches * 24} horas   ·   "
            f"Salida automática: {salida} a las {hora}")


def boton_accion(parent, texto, comando, primario=True, ancho=150, side="left"):
    return crear_boton_pill(parent, texto, comando, ancho=ancho, alto=38,
                             primario=primario, side=side, padx=(0, 10))


def tarjeta_kpi(parent, titulo, valor, color_valor=None):
    color_valor = color_valor or COLOR_TEAL
    tarjeta = tk.Frame(parent, bg=COLOR_BLANCO, highlightbackground=COLOR_NAVY,
                        highlightthickness=1)
    tk.Label(tarjeta, text=titulo, font=FUENTE_LABEL, bg=COLOR_BLANCO, fg=COLOR_BLUE) \
        .pack(anchor="w", padx=18, pady=(14, 2))
    tk.Label(tarjeta, text=str(valor), font=("Georgia", 26, "bold"),
              bg=COLOR_BLANCO, fg=color_valor).pack(anchor="w", padx=18, pady=(0, 14))
    return tarjeta


def _texto_recibo(datos):
    linea = "-" * 46
    return (
        f"{linea}\n"
        f"                BOOKROOM\n"
        f"        Recibo de reserva de habitación\n"
        f"{linea}\n"
        f"Folio (N° reserva):  {datos['folio']}\n"
        f"Fecha de emisión:    {datos['fecha_registro']}\n"
        f"Atendido por:        {datos['atendido_por']}\n"
        f"{linea}\n"
        f"Huésped:             {datos['huesped_nombre']}\n"
        f"Documento:           {datos['huesped_documento']}\n"
        f"{linea}\n"
        f"Habitación:          N° {datos['habitacion_numero']} ({datos['tipo']})\n"
        f"Entrada:             {datos['fecha_entrada']}\n"
        f"Salida:              {datos['fecha_salida']}\n"
        f"Noches:              {datos['noches']}\n"
        f"Duración:            {datos['noches'] * 24} horas\n"
        f"Precio por noche:    ${datos['precio_noche']:.2f}\n"
        f"{linea}\n"
        f"TOTAL A PAGAR:       ${datos['total']:.2f}\n"
        f"Estado:              {datos['estado']}\n"
        f"{linea}\n"
        f"       ¡Gracias por hospedarse en BookRoom!\n"
        f"{linea}\n"
    )


def mostrar_recibo(datos):
    ventana_recibo = tk.Toplevel()
    ventana_recibo.title(f"BookRoom - Recibo #{datos['folio']}")
    ventana_recibo.geometry("420x560")
    ventana_recibo.resizable(False, False)
    ventana_recibo.config(bg=COLOR_BG)

    tk.Label(ventana_recibo, text="BOOKROOM", font=("Georgia", 16, "bold"),
              bg=COLOR_BG, fg=COLOR_NAVY).pack(pady=(18, 0))
    tk.Label(ventana_recibo, text="Recibo de reserva", font=FUENTE_SUBTITULO,
              bg=COLOR_BG, fg=COLOR_BLUE).pack(pady=(0, 10))

    caja = tk.Frame(ventana_recibo, bg=COLOR_BLANCO, highlightbackground=COLOR_TEAL, highlightthickness=1)
    caja.pack(padx=24, fill="both", expand=True)

    texto_widget = tk.Text(caja, font=("Consolas", 10), bg=COLOR_BLANCO, fg=COLOR_NAVY,
                            relief="flat", wrap="word", padx=14, pady=14)
    texto_widget.pack(fill="both", expand=True)
    texto_widget.insert("1.0", _texto_recibo(datos))
    texto_widget.config(state="disabled")

    def guardar_como_archivo():
        from tkinter import filedialog
        ruta = filedialog.asksaveasfilename(
            parent=ventana_recibo,
            title="Guardar recibo",
            defaultextension=".txt",
            initialfile=f"BookRoom_recibo_{datos['folio']}.txt",
            filetypes=[("Archivo de texto", "*.txt")]
        )
        if not ruta:
            return
        try:
            with open(ruta, "w", encoding="utf-8") as archivo:
                archivo.write(_texto_recibo(datos))
            messagebox.showinfo("Recibo guardado", "El recibo se guardó correctamente.", parent=ventana_recibo)
        except Exception as e:
            messagebox.showerror("Error", str(e), parent=ventana_recibo)

    frame_botones = tk.Frame(ventana_recibo, bg=COLOR_BG)
    frame_botones.pack(fill="x", padx=24, pady=16)
    boton_accion(frame_botones, "Guardar como archivo", guardar_como_archivo, primario=True, ancho=190)
    boton_accion(frame_botones, "Cerrar", ventana_recibo.destroy, primario=False, ancho=120)


def listar_tipos_habitacion():
    conexion = conectar()
    cursor = conexion.cursor(dictionary=True)
    cursor.execute("SELECT * FROM tipos_habitacion ORDER BY id_tipo_habitacion")
    filas = cursor.fetchall()
    conexion.close()
    return filas


def crear_tipo_habitacion(nombre_tipo, descripcion, capacidad, precio):
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute(
        "INSERT INTO tipos_habitacion (nombre_tipo, descripcion, capacidad_personas, precio_por_noche) "
        "VALUES (%s, %s, %s, %s)",
        (nombre_tipo, descripcion, capacidad, precio)
    )
    conexion.commit()
    conexion.close()


def actualizar_tipo_habitacion(id_tipo, nombre_tipo, descripcion, capacidad, precio):
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute(
        "UPDATE tipos_habitacion SET nombre_tipo=%s, descripcion=%s, capacidad_personas=%s, "
        "precio_por_noche=%s WHERE id_tipo_habitacion=%s",
        (nombre_tipo, descripcion, capacidad, precio, id_tipo)
    )
    conexion.commit()
    conexion.close()


def eliminar_tipo_habitacion(id_tipo):
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute("DELETE FROM tipos_habitacion WHERE id_tipo_habitacion=%s", (id_tipo,))
    conexion.commit()
    conexion.close()


def listar_habitaciones(solo_disponibles=False):
    conexion = conectar()
    cursor = conexion.cursor(dictionary=True)
    sql = (
        "SELECT h.id_habitacion, h.numero_habitacion, h.piso, h.estado, h.precio_personalizado, "
        "t.id_tipo_habitacion, t.nombre_tipo, t.precio_por_noche AS precio_base, t.capacidad_personas, "
        "COALESCE(h.precio_personalizado, t.precio_por_noche) AS precio_por_noche "
        "FROM habitaciones h JOIN tipos_habitacion t ON h.id_tipo_habitacion = t.id_tipo_habitacion"
    )
    if solo_disponibles:
        sql += " WHERE h.estado = 'Disponible'"
    sql += " ORDER BY h.piso, h.numero_habitacion"
    cursor.execute(sql)
    filas = cursor.fetchall()
    conexion.close()
    return filas


def crear_habitacion(numero, piso, estado, id_tipo, precio_personalizado=None):
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute(
        "INSERT INTO habitaciones (numero_habitacion, piso, estado, id_tipo_habitacion, precio_personalizado) "
        "VALUES (%s, %s, %s, %s, %s)",
        (numero, piso, estado, id_tipo, precio_personalizado)
    )
    conexion.commit()
    conexion.close()


def actualizar_habitacion(id_habitacion, numero, piso, estado, id_tipo, precio_personalizado=None):
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute(
        "UPDATE habitaciones SET numero_habitacion=%s, piso=%s, estado=%s, id_tipo_habitacion=%s, "
        "precio_personalizado=%s WHERE id_habitacion=%s",
        (numero, piso, estado, id_tipo, precio_personalizado, id_habitacion)
    )
    conexion.commit()
    conexion.close()


def cambiar_estado_habitacion(id_habitacion, nuevo_estado):
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute("UPDATE habitaciones SET estado=%s WHERE id_habitacion=%s", (nuevo_estado, id_habitacion))
    conexion.commit()
    conexion.close()


def eliminar_habitacion(id_habitacion):
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute("DELETE FROM habitaciones WHERE id_habitacion=%s", (id_habitacion,))
    conexion.commit()
    conexion.close()


def listar_huespedes():
    conexion = conectar()
    cursor = conexion.cursor(dictionary=True)
    cursor.execute("SELECT * FROM huespedes ORDER BY apellido, nombre")
    filas = cursor.fetchall()
    conexion.close()
    return filas


def crear_huesped(documento, nombre, apellido, telefono, correo, direccion):
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute(
        "INSERT INTO huespedes (documento_identidad, nombre, apellido, telefono, correo_electronico, direccion) "
        "VALUES (%s, %s, %s, %s, %s, %s)",
        (documento, nombre, apellido, telefono, correo, direccion)
    )
    conexion.commit()
    id_nuevo = cursor.lastrowid
    conexion.close()
    return id_nuevo


def actualizar_huesped(id_huesped, documento, nombre, apellido, telefono, correo, direccion):
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute(
        "UPDATE huespedes SET documento_identidad=%s, nombre=%s, apellido=%s, telefono=%s, "
        "correo_electronico=%s, direccion=%s WHERE id_huesped=%s",
        (documento, nombre, apellido, telefono, correo, direccion, id_huesped)
    )
    conexion.commit()
    conexion.close()


def eliminar_huesped(id_huesped):
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute("DELETE FROM huespedes WHERE id_huesped=%s", (id_huesped,))
    conexion.commit()
    conexion.close()


def buscar_huesped_por_documento(documento):
    conexion = conectar()
    cursor = conexion.cursor(dictionary=True)
    cursor.execute("SELECT * FROM huespedes WHERE documento_identidad=%s", (documento,))
    fila = cursor.fetchone()
    conexion.close()
    return fila


def listar_reservas(estado=None):
    conexion = conectar()
    cursor = conexion.cursor(dictionary=True)
    sql = (
        "SELECT r.id_reserva, r.fecha_registro, r.fecha_entrada, r.fecha_salida, "
        "r.hora_entrada, r.hora_salida, "
        "r.estado_reserva, r.total_estimado, "
        "h.id_huesped, CONCAT(h.nombre, ' ', h.apellido) AS huesped, "
        "hab.id_habitacion, hab.numero_habitacion, "
        "u.nombre_completo AS registrado_por "
        "FROM reservas r "
        "JOIN huespedes h ON r.id_huesped = h.id_huesped "
        "JOIN habitaciones hab ON r.id_habitacion = hab.id_habitacion "
        "JOIN usuarios u ON r.id_usuario = u.id_usuario"
    )
    parametros = ()
    if estado:
        sql += " WHERE r.estado_reserva = %s"
        parametros = (estado,)
    sql += " ORDER BY r.fecha_entrada DESC"
    cursor.execute(sql, parametros)
    filas = cursor.fetchall()
    conexion.close()
    return filas


def buscar_reserva_en_conflicto(id_habitacion, fecha_entrada, fecha_salida, excluir_id_reserva=None,
                                 hora_entrada=None, hora_salida=None):
    conexion = conectar()
    cursor = conexion.cursor(dictionary=True)
    sql = (
        "SELECT r.id_reserva, r.fecha_entrada, r.fecha_salida, r.estado_reserva, "
        "CONCAT(h.nombre, ' ', h.apellido) AS huesped "
        "FROM reservas r JOIN huespedes h ON r.id_huesped = h.id_huesped "
        "WHERE r.id_habitacion=%s AND r.estado_reserva IN ('Pendiente','Confirmada') "
        "AND r.fecha_entrada < %s AND r.fecha_salida > %s"
    )
    parametros = [id_habitacion, fecha_salida, fecha_entrada]
    if hora_entrada and hora_salida:
        sql = (
            "SELECT r.id_reserva, r.fecha_entrada, r.fecha_salida, r.hora_entrada, r.hora_salida, "
            "r.estado_reserva, CONCAT(h.nombre, ' ', h.apellido) AS huesped "
            "FROM reservas r JOIN huespedes h ON r.id_huesped = h.id_huesped "
            "WHERE r.id_habitacion=%s AND r.estado_reserva IN ('Pendiente','Confirmada') "
            "AND TIMESTAMP(r.fecha_entrada, COALESCE(r.hora_entrada, '00:00:00')) < %s "
            "AND TIMESTAMP(r.fecha_salida, COALESCE(r.hora_salida, '00:00:00')) > %s"
        )
        parametros = [id_habitacion, f"{fecha_salida} {hora_salida}:00", f"{fecha_entrada} {hora_entrada}:00"]
    if excluir_id_reserva:
        sql += " AND r.id_reserva != %s"
        parametros.append(excluir_id_reserva)
    cursor.execute(sql, tuple(parametros))
    fila = cursor.fetchone()
    conexion.close()
    return fila


def crear_reserva(id_huesped, id_habitacion, id_usuario, fecha_entrada, fecha_salida, total_estimado,
                   estado_reserva="Confirmada", hora_entrada=None, hora_salida=None):
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute(
        "INSERT INTO reservas (fecha_entrada, fecha_salida, hora_entrada, hora_salida, estado_reserva, "
        "total_estimado, id_huesped, id_habitacion, id_usuario) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
        (fecha_entrada, fecha_salida, hora_entrada, hora_salida, estado_reserva, total_estimado,
         id_huesped, id_habitacion, id_usuario)
    )
    conexion.commit()
    id_nueva = cursor.lastrowid
    conexion.close()
    return id_nueva


def actualizar_estado_reserva(id_reserva, nuevo_estado):
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute("UPDATE reservas SET estado_reserva=%s WHERE id_reserva=%s", (nuevo_estado, id_reserva))
    conexion.commit()
    conexion.close()


def eliminar_reserva(id_reserva):
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute("DELETE FROM reservas WHERE id_reserva=%s", (id_reserva,))
    conexion.commit()
    conexion.close()


def listar_usuarios():
    conexion = conectar()
    cursor = conexion.cursor(dictionary=True)
    cursor.execute(
        "SELECT id_usuario, nombre_completo, usuario, rol, activo, fecha_creacion "
        "FROM usuarios ORDER BY rol DESC, nombre_completo"
    )
    filas = cursor.fetchall()
    conexion.close()
    return filas


def crear_usuario(nombre_completo, usuario, clave_hash, rol):
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute(
        "INSERT INTO usuarios (nombre_completo, usuario, clave_hash, rol) VALUES (%s, %s, %s, %s)",
        (nombre_completo, usuario, clave_hash, rol)
    )
    conexion.commit()
    conexion.close()


def cambiar_estado_usuario(id_usuario, activo):
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute("UPDATE usuarios SET activo=%s WHERE id_usuario=%s", (activo, id_usuario))
    conexion.commit()
    conexion.close()


def cambiar_rol_usuario(id_usuario, nuevo_rol):
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute("UPDATE usuarios SET rol=%s WHERE id_usuario=%s", (nuevo_rol, id_usuario))
    conexion.commit()
    conexion.close()


def contar_administradores_activos():
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute("SELECT COUNT(*) FROM usuarios WHERE rol='administrador' AND activo=1")
    total = cursor.fetchone()[0]
    conexion.close()
    return total


def eliminar_usuario(id_usuario):
    conexion = conectar()
    cursor = conexion.cursor()
    cursor.execute("DELETE FROM usuarios WHERE id_usuario=%s", (id_usuario,))
    conexion.commit()
    conexion.close()


def obtener_kpis():
    conexion = conectar()
    cursor = conexion.cursor()
    kpis = {}

    cursor.execute("SELECT COUNT(*) FROM habitaciones")
    kpis["total_habitaciones"] = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM habitaciones WHERE estado='Disponible'")
    kpis["disponibles"] = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM habitaciones WHERE estado='Ocupada'")
    kpis["ocupadas"] = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM habitaciones WHERE estado='Mantenimiento'")
    kpis["mantenimiento"] = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM reservas WHERE estado_reserva='Confirmada'")
    kpis["reservas_confirmadas"] = cursor.fetchone()[0]

    cursor.execute("SELECT COUNT(*) FROM huespedes")
    kpis["total_huespedes"] = cursor.fetchone()[0]

    conexion.close()
    return kpis


def listar_ventas_por_fecha(fecha):
    conexion = conectar()
    cursor = conexion.cursor(dictionary=True)
    cursor.execute(
        "SELECT r.id_reserva, r.fecha_registro, r.total_estimado, r.estado_reserva, "
        "u.nombre_completo AS empleado, "
        "CONCAT(h.nombre, ' ', h.apellido) AS huesped, "
        "hab.numero_habitacion, t.nombre_tipo "
        "FROM reservas r "
        "JOIN usuarios u ON r.id_usuario = u.id_usuario "
        "JOIN huespedes h ON r.id_huesped = h.id_huesped "
        "JOIN habitaciones hab ON r.id_habitacion = hab.id_habitacion "
        "JOIN tipos_habitacion t ON hab.id_tipo_habitacion = t.id_tipo_habitacion "
        "WHERE DATE(r.fecha_registro) = %s "
        "ORDER BY r.fecha_registro DESC",
        (fecha,)
    )
    filas = cursor.fetchall()
    conexion.close()
    return filas


def resumen_ventas_por_empleado(ventas_del_dia):
    resumen = {}
    for v in ventas_del_dia:
        empleado = v["empleado"]
        if empleado not in resumen:
            resumen[empleado] = {"cantidad": 0, "total": 0.0}
        resumen[empleado]["cantidad"] += 1
        resumen[empleado]["total"] += float(v["total_estimado"])
    return resumen


def resumen_ventas_por_tipo(ventas_del_dia):
    resumen = {}
    for v in ventas_del_dia:
        tipo = v["nombre_tipo"]
        if tipo not in resumen:
            resumen[tipo] = {"cantidad": 0, "total": 0.0}
        resumen[tipo]["cantidad"] += 1
        resumen[tipo]["total"] += float(v["total_estimado"])
    return resumen


def _hora_venta(venta):
    if hasattr(venta["fecha_registro"], "strftime"):
        return venta["fecha_registro"].strftime("%H:%M")
    return str(venta["fecha_registro"])


def _generar_pdf_ventas(ruta, fecha, ventas, sesion, modo):
    """Crea el PDF. modo='admin' (todos los empleados) o 'empleado' (solo las ventas de quien lo genera)."""
    from xml.sax.saxutils import escape
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.lib.enums import TA_RIGHT
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
                                     Image as RLImage, HRFlowable)

    navy = colors.HexColor(COLOR_NAVY)
    blue = colors.HexColor(COLOR_BLUE)
    teal = colors.HexColor(COLOR_TEAL)
    claro = colors.HexColor("#EDF2F7")

    es_admin = (modo == "admin")
    ancho_util = letter[0] - 3 * cm

    est_titulo = ParagraphStyle("titulo", fontName="Helvetica-Bold", fontSize=18, leading=22,
                                 textColor=navy, spaceAfter=2)
    est_sub = ParagraphStyle("sub", fontName="Helvetica", fontSize=10, leading=14, textColor=blue)
    est_h2 = ParagraphStyle("h2", fontName="Helvetica-Bold", fontSize=12, leading=15, textColor=navy,
                             spaceBefore=14, spaceAfter=6)
    est_celda = ParagraphStyle("celda", fontName="Helvetica", fontSize=8.5, leading=10.5, textColor=navy)
    est_celda_der = ParagraphStyle("celda_der", parent=est_celda, alignment=TA_RIGHT)
    est_celda_neg = ParagraphStyle("celda_neg", parent=est_celda, fontName="Helvetica-Bold")
    est_celda_neg_der = ParagraphStyle("celda_neg_der", parent=est_celda_neg, alignment=TA_RIGHT)
    est_head = ParagraphStyle("head", fontName="Helvetica-Bold", fontSize=8.5, leading=10.5,
                               textColor=colors.white)
    est_head_der = ParagraphStyle("head_der", parent=est_head, alignment=TA_RIGHT)
    est_kpi = ParagraphStyle("kpi", fontName="Helvetica", fontSize=9, leading=24, textColor=blue)
    est_total = ParagraphStyle("total", fontName="Helvetica-Bold", fontSize=12, leading=16,
                                textColor=navy, alignment=TA_RIGHT, spaceBefore=10)
    est_nota = ParagraphStyle("nota", fontName="Helvetica-Oblique", fontSize=8, leading=10, textColor=blue,
                               spaceBefore=10)

    def p(texto, estilo=est_celda):
        return Paragraph(escape(str(texto)), estilo)

    cantidad = len(ventas)
    total_general = sum(float(v["total_estimado"]) for v in ventas)
    ahora = datetime.now().strftime("%Y-%m-%d %H:%M")
    rol_visible = "Administrador" if sesion["rol"] == "administrador" else "Empleado"

    elementos = []

    ruta_logo = os.path.join(RUTA_ASSETS, "bookroom_logo.png")
    if os.path.isfile(ruta_logo):
        try:
            with Image.open(ruta_logo) as im:
                w, h = im.size
            ancho_logo = 4 * cm
            logo = RLImage(ruta_logo, width=ancho_logo, height=ancho_logo * h / w)
            logo.hAlign = "LEFT"
            elementos.append(logo)
            elementos.append(Spacer(1, 6))
        except Exception:
            pass

    elementos.append(Paragraph("Reporte de ventas" if es_admin else "Reporte de mis ventas", est_titulo))
    elementos.append(Paragraph(f"Fecha consultada: <b>{escape(fecha)}</b>", est_sub))
    elementos.append(Paragraph(
        f"Generado por: {escape(sesion['nombre_completo'])} ({rol_visible})  ·  {ahora}", est_sub))
    elementos.append(Spacer(1, 8))
    elementos.append(HRFlowable(width="100%", thickness=2, color=teal))
    elementos.append(Spacer(1, 10))

    kpis = Table([[
        Paragraph(f'Habitaciones vendidas<br/><font name="Helvetica-Bold" size="20" '
                  f'color="{COLOR_BLUE}">{cantidad}</font>', est_kpi),
        Paragraph(f'Total generado<br/><font name="Helvetica-Bold" size="20" '
                  f'color="{COLOR_BLUE}">${total_general:,.2f}</font>', est_kpi),
    ]], colWidths=[ancho_util / 2, ancho_util / 2])
    kpis.setStyle(TableStyle([
        ("BOX", (0, 0), (-1, -1), 0.8, navy),
        ("INNERGRID", (0, 0), (-1, -1), 0.8, navy),
        ("LEFTPADDING", (0, 0), (-1, -1), 12),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))
    elementos.append(kpis)

    def estilo_tabla(filas_totales=0):
        base = [
            ("BACKGROUND", (0, 0), (-1, 0), navy),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, claro]),
            ("LINEBELOW", (0, 0), (-1, -1), 0.3, colors.HexColor("#CBD5E0")),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ("LEFTPADDING", (0, 0), (-1, -1), 6),
            ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ]
        if filas_totales:
            base.append(("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#CFF5F1")))
        return TableStyle(base)

    if es_admin:
        elementos.append(Paragraph("Total vendido por empleado", est_h2))
        resumen = resumen_ventas_por_empleado(ventas)
        filas = [[p("Empleado", est_head), p("Habitaciones vendidas", est_head_der),
                  p("Total generado", est_head_der)]]
        for empleado, datos in sorted(resumen.items(), key=lambda x: x[1]["total"], reverse=True):
            filas.append([p(empleado), p(datos["cantidad"], est_celda_der),
                          p(f"${datos['total']:,.2f}", est_celda_der)])
        if not resumen:
            filas.append([p("Sin ventas registradas"), p("0", est_celda_der), p("$0.00", est_celda_der)])
        filas.append([p("TOTAL GENERAL", est_celda_neg), p(cantidad, est_celda_neg_der),
                      p(f"${total_general:,.2f}", est_celda_neg_der)])
        tabla_res = Table(filas, colWidths=[ancho_util * 0.5, ancho_util * 0.28, ancho_util * 0.22],
                           repeatRows=1)
        tabla_res.setStyle(estilo_tabla(filas_totales=1))
        elementos.append(tabla_res)

    elementos.append(Paragraph("Detalle de reservas" if es_admin else "Detalle de mis ventas", est_h2))

    if not ventas:
        elementos.append(Paragraph("No hay ventas registradas en esta fecha.", est_sub))
    else:
        if es_admin:
            encabezado = [p("ID", est_head), p("Hora", est_head), p("Empleado", est_head),
                          p("Huésped", est_head), p("Hab.", est_head), p("Tipo", est_head),
                          p("Total", est_head_der), p("Estado", est_head)]
            anchos = [1.2 * cm, 1.5 * cm, 3.6 * cm, 3.8 * cm, 1.4 * cm, 2.4 * cm, 2.2 * cm, 2.4 * cm]
        else:
            encabezado = [p("ID", est_head), p("Hora", est_head), p("Huésped", est_head),
                          p("Hab.", est_head), p("Tipo", est_head), p("Total", est_head_der),
                          p("Estado", est_head)]
            anchos = [1.3 * cm, 1.8 * cm, 5.4 * cm, 2.0 * cm, 3.2 * cm, 2.4 * cm, 2.5 * cm]

        filas = [encabezado]
        for v in ventas:
            total_v = f"${float(v['total_estimado']):,.2f}"
            if es_admin:
                filas.append([p(v["id_reserva"]), p(_hora_venta(v)), p(v["empleado"]), p(v["huesped"]),
                              p(v["numero_habitacion"]), p(v["nombre_tipo"]),
                              p(total_v, est_celda_der), p(v["estado_reserva"])])
            else:
                filas.append([p(v["id_reserva"]), p(_hora_venta(v)), p(v["huesped"]),
                              p(v["numero_habitacion"]), p(v["nombre_tipo"]),
                              p(total_v, est_celda_der), p(v["estado_reserva"])])

        tabla_det = Table(filas, colWidths=anchos, repeatRows=1)
        tabla_det.setStyle(estilo_tabla())
        elementos.append(tabla_det)

    elementos.append(Paragraph(f"Total generado: ${total_general:,.2f}", est_total))
    elementos.append(Paragraph(
        "El reporte incluye todas las reservas registradas en la fecha consultada, sin importar su estado.",
        est_nota))

    def pie(canvas, documento):
        canvas.saveState()
        canvas.setFont("Helvetica", 8)
        canvas.setFillColor(blue)
        canvas.drawString(1.5 * cm, 1 * cm, "BookRoom  ·  Sistema de Administración Hotelera")
        canvas.drawRightString(letter[0] - 1.5 * cm, 1 * cm, f"Página {documento.page}")
        canvas.restoreState()

    doc = SimpleDocTemplate(
        ruta, pagesize=letter, leftMargin=1.5 * cm, rightMargin=1.5 * cm,
        topMargin=1.5 * cm, bottomMargin=1.8 * cm,
        title="Reporte de ventas BookRoom", author=sesion["nombre_completo"]
    )
    doc.build(elementos, onFirstPage=pie, onLaterPages=pie)


def exportar_pdf_ventas(ventana, sesion, fecha, ventas, modo):
    """Pide dónde guardar y genera el reporte PDF de ventas."""
    from tkinter import filedialog

    try:
        import reportlab  # noqa: F401
    except ImportError:
        messagebox.showerror(
            "Falta una librería",
            "Para generar PDF se necesita la librería 'reportlab'.\n\n"
            "Ábrela una terminal y ejecuta:\n\n    pip install reportlab",
            parent=ventana
        )
        return

    prefijo = "reporte_ventas" if modo == "admin" else "mis_ventas"
    ruta = filedialog.asksaveasfilename(
        parent=ventana,
        title="Guardar reporte de ventas",
        defaultextension=".pdf",
        initialfile=f"BookRoom_{prefijo}_{fecha}.pdf",
        filetypes=[("Documento PDF", "*.pdf")]
    )
    if not ruta:
        return

    try:
        _generar_pdf_ventas(ruta, fecha, ventas, sesion, modo)
    except Exception as e:
        messagebox.showerror("Error al generar el PDF", str(e), parent=ventana)
        return

    if messagebox.askyesno("Reporte generado",
                            "El reporte PDF se guardó correctamente.\n¿Deseas abrirlo ahora?",
                            parent=ventana):
        try:
            os.startfile(ruta)
        except Exception:
            pass


def admin_seccion_inicio(frame, sesion):
    kpis = obtener_kpis()

    tk.Label(frame, text=f"Hola, {sesion['nombre_completo'].split()[0]}. Este es el estado del hotel hoy.",
              font=FUENTE_SUBTITULO, bg=COLOR_BG, fg=COLOR_BLUE).pack(anchor="w", padx=24, pady=(18, 10))

    fila = tk.Frame(frame, bg=COLOR_BG)
    fila.pack(fill="x", padx=24)

    datos = [
        ("Habitaciones totales", kpis["total_habitaciones"], COLOR_NAVY),
        ("Disponibles", kpis["disponibles"], COLOR_TEAL),
        ("Ocupadas", kpis["ocupadas"], COLOR_BLUE),
        ("En mantenimiento", kpis["mantenimiento"], COLOR_NAVY),
        ("Reservas confirmadas", kpis["reservas_confirmadas"], COLOR_TEAL),
        ("Huéspedes registrados", kpis["total_huespedes"], COLOR_BLUE),
    ]
    for i, (titulo, valor, color) in enumerate(datos):
        tarjeta = tarjeta_kpi(fila, titulo, valor, color)
        tarjeta.grid(row=i // 3, column=i % 3, padx=10, pady=10, sticky="nsew")
    for c in range(3):
        fila.grid_columnconfigure(c, weight=1)

    construir_grid_habitaciones(frame, listar_habitaciones())


def admin_seccion_tipos(frame, sesion):
    contenedor = tk.Frame(frame, bg=COLOR_BG)
    contenedor.pack(fill="both", expand=True)

    tabla = crear_tabla(contenedor, [
        ("id", "ID", 50), ("nombre", "Tipo", 140), ("desc", "Descripción", 300),
        ("cap", "Capacidad", 90), ("precio", "Precio/noche", 110),
    ])

    def recargar():
        tabla.delete(*tabla.get_children())
        for t in listar_tipos_habitacion():
            tabla.insert("", "end", iid=t["id_tipo_habitacion"], values=(
                t["id_tipo_habitacion"], t["nombre_tipo"], t["descripcion"] or "",
                t["capacidad_personas"], f"${t['precio_por_noche']:.2f}"
            ))

    panel_form = tk.Frame(frame, bg=COLOR_BG)
    panel_form.pack(fill="x", padx=24, pady=(0, 16))

    col1 = tk.Frame(panel_form, bg=COLOR_BG); col1.pack(side="left", padx=(0, 16))
    col2 = tk.Frame(panel_form, bg=COLOR_BG); col2.pack(side="left", padx=(0, 16))
    col3 = tk.Frame(panel_form, bg=COLOR_BG); col3.pack(side="left", padx=(0, 16))
    col4 = tk.Frame(panel_form, bg=COLOR_BG); col4.pack(side="left")

    e_nombre = campo_simple(col1, "Nombre del tipo", ancho=18)
    e_desc = campo_simple(col2, "Descripción", ancho=30)
    e_cap = campo_simple(col3, "Capacidad", ancho=8)
    e_precio = campo_simple(col4, "Precio/noche", ancho=10)

    id_seleccionado = {"valor": None}

    def limpiar():
        id_seleccionado["valor"] = None
        for e in (e_nombre, e_desc, e_cap, e_precio):
            e.delete(0, tk.END)

    def al_seleccionar(event):
        sel = tabla.selection()
        if not sel:
            return
        item = tabla.item(sel[0])["values"]
        id_seleccionado["valor"] = int(item[0])
        e_nombre.delete(0, tk.END); e_nombre.insert(0, item[1])
        e_desc.delete(0, tk.END); e_desc.insert(0, item[2])
        e_cap.delete(0, tk.END); e_cap.insert(0, item[3])
        e_precio.delete(0, tk.END); e_precio.insert(0, str(item[4]).replace("$", ""))

    tabla.bind("<<TreeviewSelect>>", al_seleccionar)

    def guardar():
        try:
            nombre = e_nombre.get().strip()
            desc = e_desc.get().strip()
            cap = int(e_cap.get().strip())
            precio = float(e_precio.get().strip())
        except ValueError:
            messagebox.showwarning("Datos inválidos", "Capacidad y precio deben ser numéricos.")
            return
        if not nombre:
            messagebox.showwarning("Campos incompletos", "El nombre del tipo es obligatorio.")
            return
        if cap <= 0 or precio <= 0:
            messagebox.showwarning("Datos inválidos", "Capacidad y precio deben ser mayores que 0.")
            return

        if id_seleccionado["valor"] is None:
            crear_tipo_habitacion(nombre, desc, cap, precio)
        else:
            actualizar_tipo_habitacion(id_seleccionado["valor"], nombre, desc, cap, precio)
        limpiar()
        recargar()

    def eliminar():
        if id_seleccionado["valor"] is None:
            messagebox.showinfo("Selecciona un tipo", "Elige un tipo de la tabla para eliminarlo.")
            return
        if messagebox.askyesno("Confirmar", "¿Eliminar este tipo de habitación?"):
            try:
                eliminar_tipo_habitacion(id_seleccionado["valor"])
                limpiar()
                recargar()
            except Exception as e:
                messagebox.showerror("No se pudo eliminar", "Hay habitaciones usando este tipo.\n" + str(e))

    frame_botones = tk.Frame(frame, bg=COLOR_BG)
    frame_botones.pack(fill="x", padx=24, pady=(0, 16))
    boton_accion(frame_botones, "Guardar", guardar, primario=True)
    boton_accion(frame_botones, "Nuevo / limpiar", limpiar, primario=False)
    boton_accion(frame_botones, "Eliminar", eliminar, primario=False)

    recargar()


def admin_seccion_habitaciones(frame, sesion):
    tabla = crear_tabla(frame, [
        ("id", "ID", 45), ("num", "N° Habitación", 100), ("piso", "Piso", 55),
        ("tipo", "Tipo", 110), ("precio_base", "Precio base", 90), ("precio_pers", "Precio personalizado", 150),
        ("estado", "Estado", 120),
    ])

    def recargar():
        tabla.delete(*tabla.get_children())
        for h in listar_habitaciones():
            personalizado = f"${float(h['precio_personalizado']):.2f}" if h["precio_personalizado"] is not None else ""
            tabla.insert("", "end", iid=h["id_habitacion"], values=(
                h["id_habitacion"], h["numero_habitacion"], h["piso"], h["nombre_tipo"],
                f"${float(h['precio_base']):.2f}", personalizado, h["estado"]
            ))

    tipos = listar_tipos_habitacion()
    mapa_tipos = {t["nombre_tipo"]: t["id_tipo_habitacion"] for t in tipos}

    tk.Label(
        frame,
        text="El precio personalizado es opcional: solo afecta a esta habitación. Déjalo vacío para usar el precio del tipo.",
        font=FUENTE_SUBTITULO, bg=COLOR_BG, fg=COLOR_BLUE
    ).pack(anchor="w", padx=24, pady=(0, 8))

    panel_form = tk.Frame(frame, bg=COLOR_BG)
    panel_form.pack(fill="x", padx=24, pady=(0, 10))

    col1 = tk.Frame(panel_form, bg=COLOR_BG); col1.pack(side="left", padx=(0, 16))
    col2 = tk.Frame(panel_form, bg=COLOR_BG); col2.pack(side="left", padx=(0, 16))
    col3 = tk.Frame(panel_form, bg=COLOR_BG); col3.pack(side="left", padx=(0, 16))
    col4 = tk.Frame(panel_form, bg=COLOR_BG); col4.pack(side="left", padx=(0, 16))
    col5 = tk.Frame(panel_form, bg=COLOR_BG); col5.pack(side="left")

    e_numero = campo_simple(col1, "N° Habitación", ancho=12)
    e_piso = campo_simple(col2, "Piso", ancho=6)
    combo_tipo = campo_simple(col3, "Tipo", ancho=14, valores_combo=list(mapa_tipos.keys()))
    combo_estado = campo_simple(col4, "Estado", ancho=14,
                                 valores_combo=["Disponible", "Ocupada", "Mantenimiento"])
    e_precio_pers = campo_simple(col5, "Precio personalizado", ancho=16)

    id_seleccionado = {"valor": None}

    def limpiar():
        id_seleccionado["valor"] = None
        e_numero.delete(0, tk.END)
        e_piso.delete(0, tk.END)
        combo_tipo.set("")
        combo_estado.set("")
        e_precio_pers.delete(0, tk.END)

    def al_seleccionar(event):
        sel = tabla.selection()
        if not sel:
            return
        v = tabla.item(sel[0])["values"]
        id_seleccionado["valor"] = int(v[0])
        e_numero.delete(0, tk.END); e_numero.insert(0, v[1])
        e_piso.delete(0, tk.END); e_piso.insert(0, v[2])
        combo_tipo.set(v[3])
        e_precio_pers.delete(0, tk.END)
        e_precio_pers.insert(0, str(v[5]).replace("$", ""))
        combo_estado.set(v[6])

    tabla.bind("<<TreeviewSelect>>", al_seleccionar)

    def guardar():
        numero = e_numero.get().strip()
        try:
            piso = int(e_piso.get().strip())
        except ValueError:
            messagebox.showwarning("Dato inválido", "El piso debe ser un número.")
            return
        if piso < 0:
            messagebox.showwarning("Dato inválido", "El piso no puede ser negativo.")
            return
        tipo_nombre = combo_tipo.get()
        estado = combo_estado.get() or "Disponible"
        precio_pers_texto = e_precio_pers.get().strip()

        if not numero or not tipo_nombre:
            messagebox.showwarning("Campos incompletos", "N° de habitación y tipo son obligatorios.")
            return

        precio_personalizado = None
        if precio_pers_texto:
            try:
                precio_personalizado = float(precio_pers_texto)
            except ValueError:
                messagebox.showwarning("Dato inválido", "El precio personalizado debe ser un número.")
                return
            if precio_personalizado <= 0:
                messagebox.showwarning("Dato inválido", "El precio personalizado debe ser mayor que 0.")
                return

        id_tipo = mapa_tipos[tipo_nombre]

        try:
            if id_seleccionado["valor"] is None:
                crear_habitacion(numero, piso, estado, id_tipo, precio_personalizado)
            else:
                actualizar_habitacion(id_seleccionado["valor"], numero, piso, estado, id_tipo, precio_personalizado)
            limpiar()
            recargar()
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def eliminar():
        if id_seleccionado["valor"] is None:
            messagebox.showinfo("Selecciona una habitación", "Elige una fila de la tabla.")
            return
        if messagebox.askyesno("Confirmar", "¿Eliminar esta habitación?"):
            try:
                eliminar_habitacion(id_seleccionado["valor"])
                limpiar()
                recargar()
            except Exception as e:
                messagebox.showerror("No se pudo eliminar", "Esta habitación tiene reservas asociadas.\n" + str(e))

    frame_botones = tk.Frame(frame, bg=COLOR_BG)
    frame_botones.pack(fill="x", padx=24, pady=(0, 16))
    boton_accion(frame_botones, "Guardar", guardar, primario=True)
    boton_accion(frame_botones, "Nuevo / limpiar", limpiar, primario=False)
    boton_accion(frame_botones, "Eliminar", eliminar, primario=False)

    recargar()


def admin_seccion_huespedes(frame, sesion):
    tabla = crear_tabla(frame, [
        ("id", "ID", 45), ("doc", "Documento", 110), ("nombre", "Nombre", 120),
        ("apellido", "Apellido", 120), ("tel", "Teléfono", 100), ("correo", "Correo", 170),
    ])

    def recargar():
        tabla.delete(*tabla.get_children())
        for h in listar_huespedes():
            tabla.insert("", "end", iid=h["id_huesped"], values=(
                h["id_huesped"], h["documento_identidad"], h["nombre"], h["apellido"],
                h["telefono"] or "", h["correo_electronico"] or ""
            ))

    panel_form = tk.Frame(frame, bg=COLOR_BG)
    panel_form.pack(fill="x", padx=24, pady=(0, 10))

    fila1 = tk.Frame(panel_form, bg=COLOR_BG); fila1.pack(anchor="w")
    fila2 = tk.Frame(panel_form, bg=COLOR_BG); fila2.pack(anchor="w")

    c1 = tk.Frame(fila1, bg=COLOR_BG); c1.pack(side="left", padx=(0, 16))
    c2 = tk.Frame(fila1, bg=COLOR_BG); c2.pack(side="left", padx=(0, 16))
    c3 = tk.Frame(fila1, bg=COLOR_BG); c3.pack(side="left")
    c4 = tk.Frame(fila2, bg=COLOR_BG); c4.pack(side="left", padx=(0, 16))
    c5 = tk.Frame(fila2, bg=COLOR_BG); c5.pack(side="left", padx=(0, 16))
    c6 = tk.Frame(fila2, bg=COLOR_BG); c6.pack(side="left")

    e_doc = campo_simple(c1, "Documento", ancho=16)
    e_nom = campo_simple(c2, "Nombre", ancho=16)
    e_ape = campo_simple(c3, "Apellido", ancho=16)
    e_tel = campo_simple(c4, "Teléfono", ancho=16)
    e_correo = campo_simple(c5, "Correo", ancho=20)
    e_dir = campo_simple(c6, "Dirección", ancho=26)

    id_seleccionado = {"valor": None}

    def limpiar():
        id_seleccionado["valor"] = None
        for e in (e_doc, e_nom, e_ape, e_tel, e_correo, e_dir):
            e.delete(0, tk.END)

    def al_seleccionar(event):
        sel = tabla.selection()
        if not sel:
            return
        v = tabla.item(sel[0])["values"]
        id_seleccionado["valor"] = int(v[0])
        for entrada, valor in zip((e_doc, e_nom, e_ape, e_tel, e_correo), v[1:6]):
            entrada.delete(0, tk.END)
            entrada.insert(0, valor)

    tabla.bind("<<TreeviewSelect>>", al_seleccionar)

    def guardar():
        doc = e_doc.get().strip()
        nom = e_nom.get().strip()
        ape = e_ape.get().strip()
        tel = e_tel.get().strip()
        correo = e_correo.get().strip()
        dire = e_dir.get().strip()

        if not doc or not nom or not ape:
            messagebox.showwarning("Campos incompletos", "Documento, nombre y apellido son obligatorios.")
            return

        error_datos = validar_datos_huesped(doc, nom, ape, tel, correo)
        if error_datos:
            messagebox.showwarning("Datos inválidos", error_datos)
            return

        try:
            if id_seleccionado["valor"] is None:
                crear_huesped(doc, nom, ape, tel, correo, dire)
            else:
                actualizar_huesped(id_seleccionado["valor"], doc, nom, ape, tel, correo, dire)
            limpiar()
            recargar()
        except Exception as e:
            messagebox.showerror("Error", "Ese documento ya está registrado o el dato no es válido.\n" + str(e))

    def eliminar():
        if id_seleccionado["valor"] is None:
            messagebox.showinfo("Selecciona un huésped", "Elige una fila de la tabla.")
            return
        if messagebox.askyesno("Confirmar", "¿Eliminar este huésped?"):
            try:
                eliminar_huesped(id_seleccionado["valor"])
                limpiar()
                recargar()
            except Exception as e:
                messagebox.showerror("No se pudo eliminar", "Este huésped tiene reservas asociadas.\n" + str(e))

    frame_botones = tk.Frame(frame, bg=COLOR_BG)
    frame_botones.pack(fill="x", padx=24, pady=(6, 16))
    boton_accion(frame_botones, "Guardar", guardar, primario=True)
    boton_accion(frame_botones, "Nuevo / limpiar", limpiar, primario=False)
    boton_accion(frame_botones, "Eliminar", eliminar, primario=False)

    recargar()


def construir_seccion_reservas(frame, sesion, permitir_eliminar=True):
    tabla = crear_tabla(frame, [
        ("id", "ID", 45), ("huesped", "Huésped", 140), ("hab", "Habitación", 85),
        ("entrada", "Entrada", 135), ("salida", "Salida", 135),
        ("total", "Total est.", 85), ("estado", "Estado", 100), ("empleado", "Registrado por", 150),
    ])

    def recargar():
        tabla.delete(*tabla.get_children())
        for r in listar_reservas():
            tabla.insert("", "end", iid=r["id_reserva"], values=(
                r["id_reserva"], r["huesped"], r["numero_habitacion"],
                _fecha_con_hora(r["fecha_entrada"], r["hora_entrada"]),
                _fecha_con_hora(r["fecha_salida"], r["hora_salida"]),
                f"${r['total_estimado']:.2f}", r["estado_reserva"], r["registrado_por"]
            ))

    huespedes = listar_huespedes()
    mapa_huespedes = {f"{h['nombre']} {h['apellido']} ({h['documento_identidad']})": h["id_huesped"]
                       for h in huespedes}
    habitaciones = listar_habitaciones()
    mapa_habitaciones = {f"{h['numero_habitacion']} - {h['nombre_tipo']} (${h['precio_por_noche']:.2f}/noche)":
                          (h["id_habitacion"], float(h["precio_por_noche"])) for h in habitaciones}

    panel_form = tk.Frame(frame, bg=COLOR_BG)
    panel_form.pack(fill="x", padx=24, pady=(0, 10))

    fila1 = tk.Frame(panel_form, bg=COLOR_BG); fila1.pack(anchor="w")
    fila2 = tk.Frame(panel_form, bg=COLOR_BG); fila2.pack(anchor="w")

    c1 = tk.Frame(fila1, bg=COLOR_BG); c1.pack(side="left", padx=(0, 16))
    c2 = tk.Frame(fila1, bg=COLOR_BG); c2.pack(side="left")
    c3 = tk.Frame(fila2, bg=COLOR_BG); c3.pack(side="left", padx=(0, 16))
    c4 = tk.Frame(fila2, bg=COLOR_BG); c4.pack(side="left")

    combo_huesped = campo_simple(c1, "Huésped", ancho=30, valores_combo=list(mapa_huespedes.keys()))
    combo_habitacion = campo_simple(c2, "Habitación", ancho=32, valores_combo=list(mapa_habitaciones.keys()))
    e_entrada = campo_fecha(c3, "Fecha entrada", ancho=22, al_cambiar=lambda: refrescar_resumen())
    e_salida = campo_fecha(c4, "Fecha salida", ancho=22, al_cambiar=lambda: refrescar_resumen())

    fila3 = tk.Frame(panel_form, bg=COLOR_BG); fila3.pack(anchor="w")
    c5 = tk.Frame(fila3, bg=COLOR_BG); c5.pack(side="left")
    campo_h = CampoHora(c5, "Hora de entrada (24 h)", al_cambiar=lambda: refrescar_resumen())

    lbl_resumen = tk.Label(panel_form, text="", font=FUENTE_SUBTITULO, bg=COLOR_BG, fg=COLOR_BLUE)
    lbl_resumen.pack(anchor="w", pady=(8, 0))

    def refrescar_resumen():
        lbl_resumen.config(text=texto_estadia(e_entrada.get().strip(), campo_h.valor(),
                                               e_salida.get().strip()))

    refrescar_resumen()

    def crear():
        huesped_sel = combo_huesped.get()
        hab_sel = combo_habitacion.get()
        entrada = e_entrada.get().strip()
        salida = e_salida.get().strip()

        if not huesped_sel or not hab_sel or not entrada or not salida:
            messagebox.showwarning("Campos incompletos", "Completa huésped, habitación y fechas.")
            return

        hora = campo_h.valor()
        if hora is None:
            messagebox.showwarning("Hora inválida", "La hora de entrada debe estar entre 00:00 y 23:59.")
            return

        id_huesped = mapa_huespedes[huesped_sel]
        id_habitacion, precio_noche = mapa_habitaciones[hab_sel]

        try:
            f_in = datetime.strptime(entrada, "%Y-%m-%d")
            f_out = datetime.strptime(salida, "%Y-%m-%d")
            noches = (f_out - f_in).days
            if noches <= 0:
                messagebox.showwarning("Fechas inválidas", "La salida debe ser posterior a la entrada.")
                return
        except ValueError:
            messagebox.showwarning("Formato inválido", "Usa el formato AAAA-MM-DD para las fechas.")
            return

        total = noches * precio_noche

        conflicto = buscar_reserva_en_conflicto(id_habitacion, entrada, salida,
                                                 hora_entrada=hora, hora_salida=hora)
        if conflicto:
            messagebox.showerror(
                "Habitación no disponible",
                f"Esa habitación ya está reservada del "
                f"{_fecha_con_hora(conflicto['fecha_entrada'], conflicto.get('hora_entrada'))} al "
                f"{_fecha_con_hora(conflicto['fecha_salida'], conflicto.get('hora_salida'))} "
                f"para {conflicto['huesped']}."
            )
            return

        id_reserva = crear_reserva(id_huesped, id_habitacion, sesion["id_usuario"], entrada, salida, total,
                                    hora_entrada=hora, hora_salida=hora)
        cambiar_estado_habitacion(id_habitacion, "Ocupada")

        nombre_huesped_doc = huesped_sel.rsplit(" (", 1)
        nombre_huesped = nombre_huesped_doc[0]
        documento_huesped = nombre_huesped_doc[1].rstrip(")") if len(nombre_huesped_doc) > 1 else ""
        numero_hab = hab_sel.split(" - ")[0]
        tipo_hab = hab_sel.split(" - ")[1].split(" (")[0]

        combo_huesped.set(""); combo_habitacion.set("")
        e_entrada.delete(0, tk.END); e_salida.delete(0, tk.END)
        campo_h.poner_ahora()
        recargar()

        mostrar_recibo({
            "folio": id_reserva,
            "fecha_registro": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "atendido_por": sesion["nombre_completo"],
            "huesped_nombre": nombre_huesped,
            "huesped_documento": documento_huesped,
            "habitacion_numero": numero_hab,
            "tipo": tipo_hab,
            "fecha_entrada": f"{entrada} {hora}",
            "fecha_salida": f"{salida} {hora}",
            "noches": noches,
            "precio_noche": precio_noche,
            "total": total,
            "estado": "Confirmada",
        })

    def cambiar_estado(nuevo_estado):
        sel = tabla.selection()
        if not sel:
            messagebox.showinfo("Selecciona una reserva", "Elige una fila de la tabla.")
            return
        id_reserva = int(sel[0])
        actualizar_estado_reserva(id_reserva, nuevo_estado)

        if nuevo_estado in ("Finalizada", "Cancelada"):
            v = tabla.item(sel[0])["values"]
            numero_hab = v[2]
            for h in listar_habitaciones():
                if str(h["numero_habitacion"]) == str(numero_hab):
                    cambiar_estado_habitacion(h["id_habitacion"], "Disponible")
                    break
        recargar()

    def eliminar():
        sel = tabla.selection()
        if not sel:
            messagebox.showinfo("Selecciona una reserva", "Elige una fila de la tabla.")
            return
        if messagebox.askyesno("Confirmar", "¿Eliminar esta reserva del historial?"):
            eliminar_reserva(int(sel[0]))
            recargar()

    frame_botones = tk.Frame(frame, bg=COLOR_BG)
    frame_botones.pack(fill="x", padx=24, pady=(6, 16))
    boton_accion(frame_botones, "Registrar reserva", crear, primario=True, ancho=170)
    boton_accion(frame_botones, "Marcar finalizada", lambda: cambiar_estado("Finalizada"), primario=False, ancho=160)
    boton_accion(frame_botones, "Cancelar reserva", lambda: cambiar_estado("Cancelada"), primario=False, ancho=150)
    if permitir_eliminar:
        boton_accion(frame_botones, "Eliminar del historial", eliminar, primario=False, ancho=180)

    recargar()


def admin_seccion_reservas(frame, sesion):
    construir_seccion_reservas(frame, sesion, permitir_eliminar=True)


def admin_seccion_usuarios(frame, sesion):
    tabla = crear_tabla(frame, [
        ("id", "ID", 45), ("nombre", "Nombre completo", 180), ("usuario", "Usuario", 120),
        ("rol", "Rol", 110), ("activo", "Estado", 90),
    ])

    def recargar():
        tabla.delete(*tabla.get_children())
        for u in listar_usuarios():
            tabla.insert("", "end", iid=u["id_usuario"], values=(
                u["id_usuario"], u["nombre_completo"], u["usuario"],
                u["rol"].capitalize(), "Activo" if u["activo"] else "Inactivo"
            ))

    panel_form = tk.Frame(frame, bg=COLOR_BG)
    panel_form.pack(fill="x", padx=24, pady=(0, 10))

    fila1 = tk.Frame(panel_form, bg=COLOR_BG); fila1.pack(anchor="w")
    fila2 = tk.Frame(panel_form, bg=COLOR_BG); fila2.pack(anchor="w")

    c1 = tk.Frame(fila1, bg=COLOR_BG); c1.pack(side="left", padx=(0, 16))
    c2 = tk.Frame(fila1, bg=COLOR_BG); c2.pack(side="left")
    c3 = tk.Frame(fila2, bg=COLOR_BG); c3.pack(side="left", padx=(0, 16))
    c4 = tk.Frame(fila2, bg=COLOR_BG); c4.pack(side="left", padx=(0, 16))
    c5 = tk.Frame(fila2, bg=COLOR_BG); c5.pack(side="left")

    e_nombre = campo_simple(c1, "Nombre completo", ancho=26)
    e_usuario = campo_simple(c2, "Usuario", ancho=20)
    e_clave = campo_simple(c3, "Contraseña", ancho=18)
    e_clave.config(show="*")
    combo_rol = campo_simple(c4, "Rol de la cuenta", ancho=16, valores_combo=["empleado", "administrador"])
    combo_rol.set("empleado")

    def crear_cuenta():
        nombre = e_nombre.get().strip()
        usuario = e_usuario.get().strip()
        clave = e_clave.get()
        rol = combo_rol.get()

        if not nombre or not usuario or not clave or not rol:
            messagebox.showwarning("Campos incompletos", "Completa todos los campos.")
            return
        if len(clave) < 6:
            messagebox.showwarning("Contraseña débil", "Usa al menos 6 caracteres.")
            return

        if rol == "administrador":
            if not messagebox.askyesno(
                "Confirmar privilegio de administrador",
                f"Estás a punto de dar rol de ADMINISTRADOR a '{usuario}'.\n"
                "Esta cuenta tendrá control total del sistema. ¿Continuar?"
            ):
                return

        try:
            clave_hash = hash_password(clave)
            crear_usuario(nombre, usuario, clave_hash, rol)
            e_nombre.delete(0, tk.END); e_usuario.delete(0, tk.END); e_clave.delete(0, tk.END)
            combo_rol.set("empleado")
            recargar()
        except Exception as e:
            messagebox.showerror("Error", "Ese usuario ya existe o el dato no es válido.\n" + str(e))

    def alternar_activo():
        sel = tabla.selection()
        if not sel:
            messagebox.showinfo("Selecciona una cuenta", "Elige una fila de la tabla.")
            return
        id_usuario = int(sel[0])
        if id_usuario == sesion["id_usuario"]:
            messagebox.showwarning("Acción no permitida", "No puedes desactivar tu propia cuenta.")
            return
        v = tabla.item(sel[0])["values"]
        nuevo_estado = 0 if v[4] == "Activo" else 1
        cambiar_estado_usuario(id_usuario, nuevo_estado)
        recargar()

    def eliminar():
        sel = tabla.selection()
        if not sel:
            messagebox.showinfo("Selecciona una cuenta", "Elige una fila de la tabla.")
            return
        id_usuario = int(sel[0])
        if id_usuario == sesion["id_usuario"]:
            messagebox.showwarning("Acción no permitida", "No puedes eliminar tu propia cuenta.")
            return
        if messagebox.askyesno("Confirmar", "¿Eliminar esta cuenta de usuario?"):
            try:
                eliminar_usuario(id_usuario)
                recargar()
            except Exception as e:
                messagebox.showerror("No se pudo eliminar", "Este usuario tiene reservas registradas.\n" + str(e))

    def cambiar_rol():
        sel = tabla.selection()
        if not sel:
            messagebox.showinfo("Selecciona una cuenta", "Elige una fila de la tabla.")
            return
        id_usuario = int(sel[0])
        v = tabla.item(sel[0])["values"]
        nombre = v[1]
        usuario = v[2]
        rol_actual = v[3].lower()

        if id_usuario == sesion["id_usuario"]:
            messagebox.showwarning("Acción no permitida", "No puedes cambiar el rol de tu propia cuenta.")
            return

        if rol_actual == "administrador" and contar_administradores_activos() <= 1:
            messagebox.showwarning(
                "Acción no permitida",
                "No puedes quitarle el rol de administrador a esta cuenta porque es "
                "la única cuenta de administrador activa del sistema."
            )
            return

        nuevo_rol = "empleado" if rol_actual == "administrador" else "administrador"

        if not messagebox.askyesno(
            "Confirmar cambio de rol",
            f"'{nombre}' ({usuario}) pasará de {rol_actual} a {nuevo_rol}. ¿Continuar?"
        ):
            return

        cambiar_rol_usuario(id_usuario, nuevo_rol)
        recargar()

    frame_botones = tk.Frame(frame, bg=COLOR_BG)
    frame_botones.pack(fill="x", padx=24, pady=(6, 16))
    boton_accion(frame_botones, "Crear cuenta", crear_cuenta, primario=True, ancho=150)
    boton_accion(frame_botones, "Cambiar rol", cambiar_rol, primario=False, ancho=140)
    boton_accion(frame_botones, "Activar / desactivar", alternar_activo, primario=False, ancho=170)
    boton_accion(frame_botones, "Eliminar cuenta", eliminar, primario=False, ancho=150)

    recargar()


def admin_seccion_ventas(frame, sesion):
    tk.Label(
        frame,
        text="Consulta cuántas habitaciones se vendieron en un día, quién las registró y cuánto se generó.",
        font=FUENTE_SUBTITULO, bg=COLOR_BG, fg=COLOR_BLUE, wraplength=1000, justify="left"
    ).pack(anchor="w", padx=24, pady=(12, 6))

    panel_filtro = tk.Frame(frame, bg=COLOR_BG)
    panel_filtro.pack(fill="x", padx=24)
    e_fecha = campo_fecha(panel_filtro, "Fecha a consultar", ancho=22, al_cambiar=lambda: consultar())
    e_fecha.insert(0, datetime.now().strftime("%Y-%m-%d"))

    fila_kpis = tk.Frame(frame, bg=COLOR_BG)
    fila_kpis.pack(fill="x", padx=24, pady=(10, 4))

    tk.Label(frame, text="Por empleado", font=("Georgia", 12, "bold"),
              bg=COLOR_BG, fg=COLOR_NAVY).pack(anchor="w", padx=24, pady=(4, 0))
    tabla_empleados = crear_tabla(frame, [
        ("empleado", "Empleado", 220), ("cantidad", "Habitaciones vendidas", 160), ("total", "Total generado", 140),
    ])

    tk.Label(frame, text="Detalle de reservas del día", font=("Georgia", 12, "bold"),
              bg=COLOR_BG, fg=COLOR_NAVY).pack(anchor="w", padx=24, pady=(6, 0))
    tabla_detalle = crear_tabla(frame, [
        ("id", "ID", 45), ("hora", "Hora", 90), ("empleado", "Empleado", 160),
        ("huesped", "Huésped", 150), ("hab", "Habitación", 90), ("tipo", "Tipo", 110),
        ("total", "Total", 90), ("estado", "Estado", 100),
    ])

    datos_actuales = {"fecha": None, "ventas": []}

    def consultar():
        fecha = e_fecha.get().strip()
        try:
            datetime.strptime(fecha, "%Y-%m-%d")
        except ValueError:
            messagebox.showwarning("Fecha inválida", "Selecciona una fecha con el calendario.")
            return

        ventas = listar_ventas_por_fecha(fecha)
        datos_actuales["fecha"] = fecha
        datos_actuales["ventas"] = ventas

        for w in fila_kpis.winfo_children():
            w.destroy()

        total_reservas = len(ventas)
        total_generado = sum(float(v["total_estimado"]) for v in ventas)

        tarjeta1 = tarjeta_kpi(fila_kpis, "Habitaciones vendidas", total_reservas, COLOR_TEAL)
        tarjeta1.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
        tarjeta2 = tarjeta_kpi(fila_kpis, "Total generado ese día", f"${total_generado:.2f}", COLOR_BLUE)
        tarjeta2.grid(row=0, column=1, padx=10, pady=10, sticky="nsew")
        for c in range(2):
            fila_kpis.grid_columnconfigure(c, weight=1)

        tabla_empleados.delete(*tabla_empleados.get_children())
        for empleado, datos in resumen_ventas_por_empleado(ventas).items():
            tabla_empleados.insert("", "end", values=(empleado, datos["cantidad"], f"${datos['total']:.2f}"))

        tabla_detalle.delete(*tabla_detalle.get_children())
        for v in ventas:
            hora = v["fecha_registro"].strftime("%H:%M") if hasattr(v["fecha_registro"], "strftime") \
                else str(v["fecha_registro"])
            tabla_detalle.insert("", "end", values=(
                v["id_reserva"], hora, v["empleado"], v["huesped"], v["numero_habitacion"],
                v["nombre_tipo"], f"${float(v['total_estimado']):.2f}", v["estado_reserva"]
            ))

    def generar_pdf():
        if datos_actuales["fecha"] is None:
            messagebox.showinfo("Sin datos", "Primero consulta una fecha.")
            return
        exportar_pdf_ventas(frame, sesion, datos_actuales["fecha"], datos_actuales["ventas"], "admin")

    frame_boton_consultar = tk.Frame(panel_filtro, bg=COLOR_BG)
    frame_boton_consultar.pack(anchor="w", pady=(14, 0))
    boton_accion(frame_boton_consultar, "Consultar", consultar, primario=True, ancho=140)
    boton_accion(frame_boton_consultar, "Generar reporte PDF", generar_pdf, primario=False, ancho=200)

    consultar()


def abrir_panel_admin(sesion):
    secciones = [
        ("inicio", "Inicio", admin_seccion_inicio),
        ("habitaciones", "Habitaciones", admin_seccion_habitaciones),
        ("tipos", "Tipos de habitación", admin_seccion_tipos),
        ("huespedes", "Huéspedes", admin_seccion_huespedes),
        ("reservas", "Reservas", admin_seccion_reservas),
        ("ventas", "Ventas", admin_seccion_ventas),
        ("usuarios", "Usuarios", admin_seccion_usuarios),
    ]
    PanelBase(sesion, "BookRoom - Panel de Administrador", secciones,
              slogan="Panel de administrador")


def emp_seccion_inicio(frame, sesion):
    kpis = obtener_kpis()
    tk.Label(frame, text=f"Hola, {sesion['nombre_completo'].split()[0]}. Resumen de habitaciones de hoy.",
              font=FUENTE_SUBTITULO, bg=COLOR_BG, fg=COLOR_BLUE).pack(anchor="w", padx=24, pady=(18, 10))

    fila = tk.Frame(frame, bg=COLOR_BG)
    fila.pack(fill="x", padx=24)
    datos = [
        ("Disponibles", kpis["disponibles"], COLOR_TEAL),
        ("Ocupadas", kpis["ocupadas"], COLOR_BLUE),
        ("En mantenimiento", kpis["mantenimiento"], COLOR_NAVY),
    ]
    for i, (titulo, valor, color) in enumerate(datos):
        tarjeta = tarjeta_kpi(fila, titulo, valor, color)
        tarjeta.grid(row=0, column=i, padx=10, pady=10, sticky="nsew")
        fila.grid_columnconfigure(i, weight=1)

    construir_grid_habitaciones(frame, listar_habitaciones())


def emp_seccion_disponibilidad(frame, sesion):
    tabla = crear_tabla(frame, [
        ("id", "ID", 45), ("num", "N° Habitación", 110), ("piso", "Piso", 60),
        ("tipo", "Tipo", 120), ("precio", "Precio/noche", 100), ("estado", "Estado", 130),
    ])

    def recargar():
        tabla.delete(*tabla.get_children())
        for h in listar_habitaciones():
            tabla.insert("", "end", iid=h["id_habitacion"], values=(
                h["id_habitacion"], h["numero_habitacion"], h["piso"], h["nombre_tipo"],
                f"${h['precio_por_noche']:.2f}", h["estado"]
            ))

    tk.Label(frame, text="Selecciona una habitación y cambia su estado (por limpieza, daños, etc.).",
              font=FUENTE_SUBTITULO, bg=COLOR_BG, fg=COLOR_BLUE).pack(anchor="w", padx=24, pady=(4, 0))

    def cambiar(nuevo_estado):
        sel = tabla.selection()
        if not sel:
            messagebox.showinfo("Selecciona una habitación", "Elige una fila de la tabla.")
            return
        cambiar_estado_habitacion(int(sel[0]), nuevo_estado)
        recargar()

    frame_botones = tk.Frame(frame, bg=COLOR_BG)
    frame_botones.pack(fill="x", padx=24, pady=(10, 16))
    boton_accion(frame_botones, "Marcar disponible", lambda: cambiar("Disponible"), primario=True, ancho=170)
    boton_accion(frame_botones, "Marcar ocupada", lambda: cambiar("Ocupada"), primario=False, ancho=170)
    boton_accion(frame_botones, "Marcar mantenimiento", lambda: cambiar("Mantenimiento"), primario=False, ancho=190)

    recargar()


def emp_seccion_huespedes(frame, sesion):
    tabla = crear_tabla(frame, [
        ("id", "ID", 45), ("doc", "Documento", 110), ("nombre", "Nombre", 130),
        ("apellido", "Apellido", 130), ("tel", "Teléfono", 110), ("correo", "Correo", 170),
    ])

    def recargar():
        tabla.delete(*tabla.get_children())
        for h in listar_huespedes():
            tabla.insert("", "end", iid=h["id_huesped"], values=(
                h["id_huesped"], h["documento_identidad"], h["nombre"], h["apellido"],
                h["telefono"] or "", h["correo_electronico"] or ""
            ))

    panel_form = tk.Frame(frame, bg=COLOR_BG)
    panel_form.pack(fill="x", padx=24, pady=(0, 10))
    fila1 = tk.Frame(panel_form, bg=COLOR_BG); fila1.pack(anchor="w")
    fila2 = tk.Frame(panel_form, bg=COLOR_BG); fila2.pack(anchor="w")

    c1 = tk.Frame(fila1, bg=COLOR_BG); c1.pack(side="left", padx=(0, 16))
    c2 = tk.Frame(fila1, bg=COLOR_BG); c2.pack(side="left", padx=(0, 16))
    c3 = tk.Frame(fila1, bg=COLOR_BG); c3.pack(side="left")
    c4 = tk.Frame(fila2, bg=COLOR_BG); c4.pack(side="left", padx=(0, 16))
    c5 = tk.Frame(fila2, bg=COLOR_BG); c5.pack(side="left")

    e_doc = campo_simple(c1, "Documento", ancho=16)
    e_nom = campo_simple(c2, "Nombre", ancho=16)
    e_ape = campo_simple(c3, "Apellido", ancho=16)
    e_tel = campo_simple(c4, "Teléfono", ancho=16)
    e_correo = campo_simple(c5, "Correo", ancho=22)

    def guardar():
        doc, nom, ape = e_doc.get().strip(), e_nom.get().strip(), e_ape.get().strip()
        tel, correo = e_tel.get().strip(), e_correo.get().strip()
        if not doc or not nom or not ape:
            messagebox.showwarning("Campos incompletos", "Documento, nombre y apellido son obligatorios.")
            return
        error_datos = validar_datos_huesped(doc, nom, ape, tel, correo)
        if error_datos:
            messagebox.showwarning("Datos inválidos", error_datos)
            return
        try:
            crear_huesped(doc, nom, ape, tel, correo, "")
            for e in (e_doc, e_nom, e_ape, e_tel, e_correo):
                e.delete(0, tk.END)
            recargar()
        except Exception as e:
            messagebox.showerror("Error", "Ese documento ya está registrado.\n" + str(e))

    frame_botones = tk.Frame(frame, bg=COLOR_BG)
    frame_botones.pack(fill="x", padx=24, pady=(6, 16))
    boton_accion(frame_botones, "Registrar huésped", guardar, primario=True, ancho=170)

    recargar()


def emp_seccion_checkin(frame, sesion):
    tk.Label(frame, text="Registra la entrada de un huésped asignándole una habitación disponible.",
              font=FUENTE_SUBTITULO, bg=COLOR_BG, fg=COLOR_BLUE).pack(anchor="w", padx=24, pady=(10, 6))

    huespedes = listar_huespedes()
    mapa_huespedes = {f"{h['nombre']} {h['apellido']} ({h['documento_identidad']})": h["id_huesped"]
                       for h in huespedes}
    habitaciones = listar_habitaciones(solo_disponibles=True)
    mapa_habitaciones = {f"{h['numero_habitacion']} - {h['nombre_tipo']} (${h['precio_por_noche']:.2f}/noche)":
                          (h["id_habitacion"], float(h["precio_por_noche"])) for h in habitaciones}

    panel_form = tk.Frame(frame, bg=COLOR_BG)
    panel_form.pack(fill="x", padx=24, pady=(0, 10))
    fila1 = tk.Frame(panel_form, bg=COLOR_BG); fila1.pack(anchor="w")
    fila2 = tk.Frame(panel_form, bg=COLOR_BG); fila2.pack(anchor="w")

    c1 = tk.Frame(fila1, bg=COLOR_BG); c1.pack(side="left", padx=(0, 16))
    c2 = tk.Frame(fila1, bg=COLOR_BG); c2.pack(side="left")
    c3 = tk.Frame(fila2, bg=COLOR_BG); c3.pack(side="left", padx=(0, 16))
    c4 = tk.Frame(fila2, bg=COLOR_BG); c4.pack(side="left")

    combo_huesped = campo_simple(c1, "Huésped", ancho=30, valores_combo=list(mapa_huespedes.keys()))
    combo_habitacion = campo_simple(c2, "Habitación disponible", ancho=34, valores_combo=list(mapa_habitaciones.keys()))
    e_entrada = campo_fecha(c3, "Fecha entrada", ancho=22, al_cambiar=lambda: refrescar_resumen())
    e_salida = campo_fecha(c4, "Fecha salida", ancho=22, al_cambiar=lambda: refrescar_resumen())

    fila3 = tk.Frame(panel_form, bg=COLOR_BG); fila3.pack(anchor="w")
    c5 = tk.Frame(fila3, bg=COLOR_BG); c5.pack(side="left")
    campo_h = CampoHora(c5, "Hora de entrada (24 h)", al_cambiar=lambda: refrescar_resumen())

    lbl_resumen = tk.Label(panel_form, text="", font=FUENTE_SUBTITULO, bg=COLOR_BG, fg=COLOR_BLUE)
    lbl_resumen.pack(anchor="w", pady=(8, 0))

    def refrescar_resumen():
        lbl_resumen.config(text=texto_estadia(e_entrada.get().strip(), campo_h.valor(),
                                               e_salida.get().strip()))

    e_entrada.insert(0, datetime.now().strftime("%Y-%m-%d"))
    refrescar_resumen()

    def registrar():
        huesped_sel = combo_huesped.get()
        hab_sel = combo_habitacion.get()
        entrada, salida = e_entrada.get().strip(), e_salida.get().strip()

        if not huesped_sel or not hab_sel or not entrada or not salida:
            messagebox.showwarning("Campos incompletos", "Completa huésped, habitación y fechas.")
            return

        hora = campo_h.valor()
        if hora is None:
            messagebox.showwarning("Hora inválida", "La hora de entrada debe estar entre 00:00 y 23:59.")
            return

        id_huesped = mapa_huespedes[huesped_sel]
        id_habitacion, precio_noche = mapa_habitaciones[hab_sel]

        try:
            f_in = datetime.strptime(entrada, "%Y-%m-%d")
            f_out = datetime.strptime(salida, "%Y-%m-%d")
            noches = (f_out - f_in).days
            if noches <= 0:
                messagebox.showwarning("Fechas inválidas", "La salida debe ser posterior a la entrada.")
                return
        except ValueError:
            messagebox.showwarning("Formato inválido", "Usa el formato AAAA-MM-DD.")
            return

        total = noches * precio_noche

        conflicto = buscar_reserva_en_conflicto(id_habitacion, entrada, salida,
                                                 hora_entrada=hora, hora_salida=hora)
        if conflicto:
            messagebox.showerror(
                "Habitación no disponible",
                f"Esa habitación ya está reservada del "
                f"{_fecha_con_hora(conflicto['fecha_entrada'], conflicto.get('hora_entrada'))} al "
                f"{_fecha_con_hora(conflicto['fecha_salida'], conflicto.get('hora_salida'))} "
                f"para {conflicto['huesped']}."
            )
            return

        id_reserva = crear_reserva(id_huesped, id_habitacion, sesion["id_usuario"], entrada, salida, total,
                                    estado_reserva="Confirmada", hora_entrada=hora, hora_salida=hora)
        cambiar_estado_habitacion(id_habitacion, "Ocupada")

        nombre_huesped_doc = huesped_sel.rsplit(" (", 1)
        nombre_huesped = nombre_huesped_doc[0]
        documento_huesped = nombre_huesped_doc[1].rstrip(")") if len(nombre_huesped_doc) > 1 else ""
        numero_hab = hab_sel.split(" - ")[0]
        tipo_hab = hab_sel.split(" - ")[1].split(" (")[0]

        nuevas = listar_habitaciones(solo_disponibles=True)
        nuevo_mapa = {f"{h['numero_habitacion']} - {h['nombre_tipo']} (${h['precio_por_noche']:.2f}/noche)":
                      (h["id_habitacion"], float(h["precio_por_noche"])) for h in nuevas}
        mapa_habitaciones.clear()
        mapa_habitaciones.update(nuevo_mapa)
        combo_habitacion.config(values=list(mapa_habitaciones.keys()))
        combo_habitacion.set("")
        combo_huesped.set("")
        campo_h.poner_ahora()

        mostrar_recibo({
            "folio": id_reserva,
            "fecha_registro": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "atendido_por": sesion["nombre_completo"],
            "huesped_nombre": nombre_huesped,
            "huesped_documento": documento_huesped,
            "habitacion_numero": numero_hab,
            "tipo": tipo_hab,
            "fecha_entrada": f"{entrada} {hora}",
            "fecha_salida": f"{salida} {hora}",
            "noches": noches,
            "precio_noche": precio_noche,
            "total": total,
            "estado": "Confirmada",
        })

    frame_botones = tk.Frame(frame, bg=COLOR_BG)
    frame_botones.pack(fill="x", padx=24, pady=(6, 16))
    boton_accion(frame_botones, "Registrar entrada", registrar, primario=True, ancho=180)


def emp_seccion_checkout(frame, sesion):
    tk.Label(frame, text="Reservas activas: selecciona una y confirma la salida del huésped.",
              font=FUENTE_SUBTITULO, bg=COLOR_BG, fg=COLOR_BLUE).pack(anchor="w", padx=24, pady=(10, 0))

    tabla = crear_tabla(frame, [
        ("id", "ID", 45), ("huesped", "Huésped", 160), ("hab", "Habitación", 100),
        ("entrada", "Entrada", 140), ("salida", "Salida prevista", 150), ("total", "Total est.", 100),
    ])

    def recargar():
        tabla.delete(*tabla.get_children())
        for r in listar_reservas(estado="Confirmada"):
            tabla.insert("", "end", iid=r["id_reserva"], values=(
                r["id_reserva"], r["huesped"], r["numero_habitacion"],
                _fecha_con_hora(r["fecha_entrada"], r["hora_entrada"]),
                _fecha_con_hora(r["fecha_salida"], r["hora_salida"]), f"${r['total_estimado']:.2f}"
            ))

    def confirmar_salida():
        sel = tabla.selection()
        if not sel:
            messagebox.showinfo("Selecciona una reserva", "Elige una fila de la tabla.")
            return
        id_reserva = int(sel[0])
        v = tabla.item(sel[0])["values"]
        numero_hab = v[2]

        aviso = ""
        try:
            reserva = next((r for r in listar_reservas(estado="Confirmada")
                            if r["id_reserva"] == id_reserva), None)
            if reserva and reserva["hora_salida"] is not None:
                h, m = _formatear_hora(reserva["hora_salida"]).split(":")
                prevista = datetime.combine(reserva["fecha_salida"], datetime.min.time()).replace(
                    hour=int(h), minute=int(m))
                ahora = datetime.now()
                if ahora > prevista:
                    minutos = int((ahora - prevista).total_seconds() // 60)
                    aviso = (f"\n\nSalida tardía: se pasó de la hora prevista "
                             f"({prevista.strftime('%Y-%m-%d %H:%M')}) por {minutos // 60} h {minutos % 60} min.")
        except Exception:
            aviso = ""

        actualizar_estado_reserva(id_reserva, "Finalizada")
        for h in listar_habitaciones():
            if str(h["numero_habitacion"]) == str(numero_hab):
                cambiar_estado_habitacion(h["id_habitacion"], "Disponible")
                break
        messagebox.showinfo("Salida registrada", "La habitación vuelve a estar disponible." + aviso)
        recargar()

    frame_botones = tk.Frame(frame, bg=COLOR_BG)
    frame_botones.pack(fill="x", padx=24, pady=(10, 16))
    boton_accion(frame_botones, "Confirmar salida", confirmar_salida, primario=True, ancho=170)

    recargar()


def emp_seccion_ventas(frame, sesion):
    tk.Label(frame, text="Consulta las habitaciones que vendiste en el día seleccionado.",
              font=FUENTE_SUBTITULO, bg=COLOR_BG, fg=COLOR_BLUE).pack(anchor="w", padx=24, pady=(14, 6))

    panel_filtro = tk.Frame(frame, bg=COLOR_BG)
    panel_filtro.pack(fill="x", padx=24)
    e_fecha = campo_fecha(panel_filtro, "Fecha a consultar", ancho=22, al_cambiar=lambda: consultar())
    e_fecha.insert(0, datetime.now().strftime("%Y-%m-%d"))

    fila_kpis = tk.Frame(frame, bg=COLOR_BG)
    fila_kpis.pack(fill="x", padx=24, pady=(10, 0))

    tabla = crear_tabla(frame, [
        ("id", "ID", 45), ("hora", "Hora", 90), ("huesped", "Huésped", 160),
        ("hab", "Habitación", 90), ("tipo", "Tipo", 120), ("total", "Total", 90), ("estado", "Estado", 100),
    ])

    datos_actuales = {"fecha": None, "ventas": []}

    def consultar():
        fecha = e_fecha.get().strip()
        try:
            datetime.strptime(fecha, "%Y-%m-%d")
        except ValueError:
            messagebox.showwarning("Fecha inválida", "Selecciona una fecha con el calendario.")
            return

        ventas = [v for v in listar_ventas_por_fecha(fecha) if v["empleado"] == sesion["nombre_completo"]]
        datos_actuales["fecha"] = fecha
        datos_actuales["ventas"] = ventas

        total_reservas = len(ventas)
        total_generado = sum(float(v["total_estimado"]) for v in ventas)

        for w in fila_kpis.winfo_children():
            w.destroy()
        t1 = tarjeta_kpi(fila_kpis, "Habitaciones vendidas", total_reservas, COLOR_TEAL)
        t1.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
        t2 = tarjeta_kpi(fila_kpis, "Total generado por ti", f"${total_generado:.2f}", COLOR_BLUE)
        t2.grid(row=0, column=1, padx=10, pady=10, sticky="nsew")
        fila_kpis.grid_columnconfigure(0, weight=1)
        fila_kpis.grid_columnconfigure(1, weight=1)

        tabla.delete(*tabla.get_children())
        for v in ventas:
            tabla.insert("", "end", values=(
                v["id_reserva"], _hora_venta(v), v["huesped"], v["numero_habitacion"], v["nombre_tipo"],
                f"${float(v['total_estimado']):.2f}", v["estado_reserva"]
            ))

    def generar_pdf():
        if datos_actuales["fecha"] is None:
            messagebox.showinfo("Sin datos", "Primero consulta una fecha.")
            return
        exportar_pdf_ventas(frame, sesion, datos_actuales["fecha"], datos_actuales["ventas"], "empleado")

    frame_boton_consultar = tk.Frame(panel_filtro, bg=COLOR_BG)
    frame_boton_consultar.pack(anchor="w", pady=(14, 0))
    boton_accion(frame_boton_consultar, "Consultar", consultar, primario=True, ancho=140)
    boton_accion(frame_boton_consultar, "Generar reporte PDF", generar_pdf, primario=False, ancho=200)

    consultar()


def emp_seccion_reservas(frame, sesion):
    construir_seccion_reservas(frame, sesion, permitir_eliminar=False)


def abrir_panel_empleado(sesion):
    secciones = [
        ("inicio", "Inicio", emp_seccion_inicio),
        ("disponibilidad", "Disponibilidad", emp_seccion_disponibilidad),
        ("checkin", "Registrar entrada", emp_seccion_checkin),
        ("checkout", "Registrar salida", emp_seccion_checkout),
        ("reservas", "Reservas", emp_seccion_reservas),
        ("huespedes", "Huéspedes", emp_seccion_huespedes),
        ("ventas", "Mis ventas", emp_seccion_ventas),
    ]
    PanelBase(sesion, "BookRoom - Panel de Recepción", secciones,
              slogan="Panel de recepción")


def abrir_registro(ventana_padre):
    registro = tk.Toplevel(ventana_padre)
    registro.title("Crear cuenta de empleado - BookRoom")
    registro.geometry("960x600")
    registro.resizable(False, False)
    registro.config(bg=COLOR_BG)

    crear_sidebar(registro, 600, texto_slogan="Únete al equipo BookRoom")

    panel_derecho = tk.Frame(registro, bg=COLOR_BG)
    panel_derecho.pack(side="left", fill="both", expand=True, padx=40, pady=30)

    tk.Label(
        panel_derecho, text="Crear cuenta de empleado",
        font=FUENTE_TITULO, bg=COLOR_BG, fg=COLOR_NAVY
    ).pack(anchor="w", pady=(0, 2))

    tk.Label(
        panel_derecho,
        text="Registra tu acceso como personal de recepción del hotel.\n"
             "Las cuentas de administrador no se crean por este medio.",
        font=FUENTE_SUBTITULO, bg=COLOR_BG, fg=COLOR_BLUE, justify="left"
    ).pack(anchor="w", pady=(0, 20))

    frame_formulario = tk.Frame(panel_derecho, bg=COLOR_BG)
    frame_formulario.pack(anchor="w")

    columna_izq = tk.Frame(frame_formulario, bg=COLOR_BG)
    columna_izq.grid(row=0, column=0, padx=(0, 20))

    columna_der = tk.Frame(frame_formulario, bg=COLOR_BG)
    columna_der.grid(row=0, column=1)

    entrada_nombre = crear_campo_pill(columna_izq, "Nombre completo", ancho=290)
    entrada_clave = crear_campo_pill(columna_izq, "Contraseña", ancho=290, es_password=True)

    entrada_usuario = crear_campo_pill(columna_der, "Usuario", ancho=290)
    entrada_confirmar = crear_campo_pill(columna_der, "Confirmar contraseña", ancho=290, es_password=True)

    def registrar_usuario():
        nombre = entrada_nombre.get().strip()
        usuario = entrada_usuario.get().strip()
        clave = entrada_clave.get()
        confirmar = entrada_confirmar.get()

        if not nombre or not usuario or not clave:
            messagebox.showwarning("Campos incompletos", "Llena todos los campos.", parent=registro)
            return

        if len(clave) < 6:
            messagebox.showwarning("Contraseña débil", "Usa al menos 6 caracteres.", parent=registro)
            return

        if clave != confirmar:
            messagebox.showwarning("Error", "Las contraseñas no coinciden.", parent=registro)
            return

        try:
            clave_hash = hash_password(clave)
            conexion = conectar()
            cursor = conexion.cursor()
            sql = ("INSERT INTO usuarios (nombre_completo, usuario, clave_hash, rol) "
                   "VALUES (%s, %s, %s, %s)")
            cursor.execute(sql, (nombre, usuario, clave_hash, ROL_PERMITIDO_EN_REGISTRO_PUBLICO))
            conexion.commit()
            conexion.close()

            messagebox.showinfo("Cuenta creada",
                                 "Tu cuenta de empleado se registró correctamente.",
                                 parent=registro)
            registro.destroy()

        except mysql.connector.IntegrityError:
            messagebox.showerror("Error", "Ese nombre de usuario ya existe.", parent=registro)
        except Exception as e:
            messagebox.showerror("Error", str(e), parent=registro)

    frame_botones = tk.Frame(panel_derecho, bg=COLOR_BG)
    frame_botones.pack(fill="x", pady=(30, 0))

    crear_boton_pill(frame_botones, "Crear cuenta", registrar_usuario, ancho=170, primario=True)
    crear_boton_pill(frame_botones, "Cancelar", registro.destroy, ancho=140, primario=False)


def iniciar_sesion(ventana, entrada_usuario, entrada_clave):
    usuario = entrada_usuario.get().strip()
    clave = entrada_clave.get()

    if not usuario or not clave:
        messagebox.showwarning("Campos incompletos", "Ingresa usuario y contraseña.", parent=ventana)
        return

    try:
        conexion = conectar()
        cursor = conexion.cursor(dictionary=True)
        cursor.execute(
            "SELECT id_usuario, nombre_completo, usuario, clave_hash, rol, activo "
            "FROM usuarios WHERE usuario=%s",
            (usuario,)
        )
        fila = cursor.fetchone()
        conexion.close()

        if not fila or not verificar_password(clave, fila["clave_hash"]):
            messagebox.showerror("Acceso denegado", "Usuario o contraseña incorrectos.", parent=ventana)
            return

        if not fila["activo"]:
            messagebox.showerror("Cuenta inactiva", "Esta cuenta fue deshabilitada. Contacta al administrador.",
                                  parent=ventana)
            return

        sesion = {
            "id_usuario": fila["id_usuario"],
            "nombre_completo": fila["nombre_completo"],
            "usuario": fila["usuario"],
            "rol": fila["rol"],
        }

        ventana.destroy()

        if sesion["rol"] == "administrador":
            abrir_panel_admin(sesion)
        else:
            abrir_panel_empleado(sesion)

    except Exception as e:
        messagebox.showerror("Error de conexión", str(e), parent=ventana)


def construir_login():
    ventana = tk.Tk()
    ventana.title("BookRoom - Sistema de Administración Hotelera")
    ventana.geometry("760x560")
    ventana.resizable(False, False)
    ventana.config(bg=COLOR_BG)
    aplicar_icono(ventana)

    crear_sidebar(ventana, 560)

    panel_derecho = tk.Frame(ventana, bg=COLOR_BG)
    panel_derecho.pack(side="left", fill="both", expand=True)

    contenido = tk.Frame(panel_derecho, bg=COLOR_BG)
    contenido.place(relx=0.5, rely=0.5, anchor="center")

    tk.Label(
        contenido, text="Bienvenido de nuevo",
        font=FUENTE_TITULO, bg=COLOR_BG, fg=COLOR_NAVY
    ).pack(pady=(0, 2))

    tk.Label(
        contenido, text="Inicia sesión para acceder al panel de BookRoom",
        font=FUENTE_SUBTITULO, bg=COLOR_BG, fg=COLOR_BLUE
    ).pack(pady=(0, 20))

    frame_formulario = tk.Frame(contenido, bg=COLOR_BG)
    frame_formulario.pack()

    entrada_usuario = crear_campo_pill(frame_formulario, "Usuario", ancho=340)
    entrada_clave = crear_campo_pill(frame_formulario, "Contraseña", ancho=340, es_password=True)

    frame_link = tk.Frame(contenido, bg=COLOR_BG)
    frame_link.pack(pady=(14, 0))

    tk.Label(
        frame_link, text="¿No tienes cuenta de empleado?",
        font=FUENTE_SUBTITULO, bg=COLOR_BG, fg=COLOR_BLUE
    ).pack(side="left")

    link_registro = tk.Label(
        frame_link, text=" Regístrate aquí",
        font=("Georgia", 10, "bold underline"),
        bg=COLOR_BG, fg=COLOR_NAVY, cursor="hand2"
    )
    link_registro.pack(side="left")
    link_registro.bind("<Button-1>", lambda e: abrir_registro(ventana))

    frame_botones_inner = tk.Frame(contenido, bg=COLOR_BG)
    frame_botones_inner.pack(pady=(34, 0))

    crear_boton_pill(frame_botones_inner, "Salir", ventana.destroy, ancho=140, primario=False,
                      side="left", padx=(6, 6))
    crear_boton_pill(frame_botones_inner, "Ingresar",
                      lambda: iniciar_sesion(ventana, entrada_usuario, entrada_clave),
                      ancho=150, primario=True, side="left", padx=(6, 6))

    ventana.bind("<Return>", lambda e: iniciar_sesion(ventana, entrada_usuario, entrada_clave))

    ventana.mainloop()


def existe_administrador():
    try:
        conexion = conectar()
        cursor = conexion.cursor()
        cursor.execute("SELECT COUNT(*) FROM usuarios WHERE rol='administrador'")
        total = cursor.fetchone()[0]
        conexion.close()
        return total > 0
    except Exception as e:
        messagebox.showerror(
            "Error de conexión",
            "No se pudo conectar a la base de datos 'bookroom'.\n"
            "Verifica que ejecutaste bookroom_schema.sql y que CONFIG_DB "
            "tiene las credenciales correctas.\n\n" + str(e)
        )
        raise SystemExit


def construir_configuracion_inicial():
    ventana = tk.Tk()
    ventana.title("BookRoom - Configuración inicial")
    ventana.geometry("760x560")
    ventana.resizable(False, False)
    ventana.config(bg=COLOR_BG)
    aplicar_icono(ventana)

    crear_sidebar(ventana, 560, texto_slogan="Primer arranque del sistema")

    panel_derecho = tk.Frame(ventana, bg=COLOR_BG)
    panel_derecho.pack(side="left", fill="both", expand=True, padx=45, pady=40)

    tk.Label(
        panel_derecho, text="Crear administrador inicial",
        font=FUENTE_TITULO, bg=COLOR_BG, fg=COLOR_NAVY
    ).pack(anchor="w", pady=(0, 2))

    tk.Label(
        panel_derecho,
        text="Aún no existe ninguna cuenta de administrador.\n"
             "Crea la primera aquí (solo se pedirá esta vez).",
        font=FUENTE_SUBTITULO, bg=COLOR_BG, fg=COLOR_BLUE, justify="left"
    ).pack(anchor="w", pady=(0, 20))

    frame_formulario = tk.Frame(panel_derecho, bg=COLOR_BG)
    frame_formulario.pack(anchor="w")

    entrada_nombre = crear_campo_pill(frame_formulario, "Nombre completo", ancho=340)
    entrada_usuario = crear_campo_pill(frame_formulario, "Usuario", ancho=340)
    entrada_clave = crear_campo_pill(frame_formulario, "Contraseña", ancho=340, es_password=True)
    entrada_confirmar = crear_campo_pill(frame_formulario, "Confirmar contraseña", ancho=340, es_password=True)

    def crear_admin():
        nombre = entrada_nombre.get().strip()
        usuario = entrada_usuario.get().strip()
        clave = entrada_clave.get()
        confirmar = entrada_confirmar.get()

        if not nombre or not usuario or not clave:
            messagebox.showwarning("Campos incompletos", "Llena todos los campos.", parent=ventana)
            return
        if len(clave) < 6:
            messagebox.showwarning("Contraseña débil", "Usa al menos 6 caracteres.", parent=ventana)
            return
        if clave != confirmar:
            messagebox.showwarning("Error", "Las contraseñas no coinciden.", parent=ventana)
            return

        try:
            clave_hash = hash_password(clave)
            conexion = conectar()
            cursor = conexion.cursor()
            cursor.execute(
                "INSERT INTO usuarios (nombre_completo, usuario, clave_hash, rol) "
                "VALUES (%s, %s, %s, 'administrador')",
                (nombre, usuario, clave_hash)
            )
            conexion.commit()
            conexion.close()
            messagebox.showinfo("Listo", "Cuenta de administrador creada. Ahora inicia sesión.", parent=ventana)
            ventana.destroy()
            construir_login()
        except mysql.connector.IntegrityError:
            messagebox.showerror("Error", "Ese nombre de usuario ya existe.", parent=ventana)
        except Exception as e:
            messagebox.showerror("Error", str(e), parent=ventana)

    frame_botones = tk.Frame(panel_derecho, bg=COLOR_BG)
    frame_botones.pack(fill="x", pady=(30, 0))
    crear_boton_pill(frame_botones, "Crear administrador", crear_admin, ancho=200, primario=True)
    crear_boton_pill(frame_botones, "Salir", ventana.destroy, ancho=140, primario=False)

    ventana.mainloop()


if __name__ == "__main__":
    hay_admin = existe_administrador()
    try:
        asegurar_columnas_horas()
    except Exception as error_migracion:
        messagebox.showerror("Error al actualizar la base de datos",
                              "No se pudieron agregar las columnas de hora a la tabla 'reservas'.\n\n"
                              + str(error_migracion))
        raise SystemExit
    if hay_admin:
        construir_login()
    else:
        construir_configuracion_inicial()